﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace Cargo_Management_system
{
    public partial class VeichleRegisterationForm : Form
    {
        public VeichleRegisterationForm()
        {
            InitializeComponent();
        }

        private void VRdataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        


        private void Vinsertbutton_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-04KFGU9\\SQLSERVER2022;Initial Catalog=\"Cargo Management System\";Integrated Security=True;Encrypt=False"; 
            string insertQuery = @"
        INSERT INTO Vehicles (Make, Model, Year, Status, Capacity, VeichleType)
        VALUES (@Make, @Model, @Year, @Status, @Capacity, @VeichleType)";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(insertQuery, con))
                {
                    // Replace "textBoxMake.Text", etc., with your actual control names
                    cmd.Parameters.AddWithValue("@Make", VMatextBox.Text);
                    cmd.Parameters.AddWithValue("@Model", VMotextBox.Text);
                    cmd.Parameters.AddWithValue("@Year", int.Parse(VYtextBox.Text));
                    cmd.Parameters.AddWithValue("@Status", VRstatuscomboobx.Text);
                    cmd.Parameters.AddWithValue("@Capacity", decimal.Parse(VCtextBox.Text));
                    cmd.Parameters.AddWithValue("@VeichleType", VTtextBox.Text);

                    try
                    {
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();

                        // Show a success message
                        MessageBox.Show("Vehicle data inserted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        // Show an error message
                        MessageBox.Show($"Error inserting data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            this.Close();
        }

        private void VeichleRegisterationForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'cargo_Management_SystemDataSet.Vehicles' table. You can move, or remove it, as needed.
            this.vehiclesTableAdapter.Fill(this.cargo_Management_SystemDataSet.Vehicles);

        }

        private void VRExitbutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}