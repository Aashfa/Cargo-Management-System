﻿namespace Cargo_Management_system
{
    partial class ManageMaintananceRecordForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.VehicleIDcomboBox = new System.Windows.Forms.ComboBox();
            this.vehiclesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cargo_Management_SystemDataSet = new Cargo_Management_system.Cargo_Management_SystemDataSet();
            this.CosttextBox = new System.Windows.Forms.TextBox();
            this.DescriptiontextBox = new System.Windows.Forms.TextBox();
            this.MaintenancedateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.locnamelabel = new System.Windows.Forms.Label();
            this.ExitMaintananceRecordbutton = new System.Windows.Forms.Button();
            this.DeleteMaintananceRecordbutton = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.MaintenancedataGridView = new System.Windows.Forms.DataGridView();
            this.recordIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vehicleIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.costDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.maintenanceRecordsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.warehouseformpanel = new System.Windows.Forms.Panel();
            this.MaintenanceRecordFormlabel = new System.Windows.Forms.Label();
            this.namelabel = new System.Windows.Forms.Label();
            this.maintenanceRecordsTableAdapter = new Cargo_Management_system.Cargo_Management_SystemDataSetTableAdapters.MaintenanceRecordsTableAdapter();
            this.UpdateMaintananceRecordbutton = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.RecordIDcomboBox = new System.Windows.Forms.ComboBox();
            this.maintenanceRecordsBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.vehiclesTableAdapter = new Cargo_Management_system.Cargo_Management_SystemDataSetTableAdapters.VehiclesTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.vehiclesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cargo_Management_SystemDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MaintenancedataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.maintenanceRecordsBindingSource)).BeginInit();
            this.warehouseformpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.maintenanceRecordsBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // VehicleIDcomboBox
            // 
            this.VehicleIDcomboBox.DataSource = this.vehiclesBindingSource;
            this.VehicleIDcomboBox.DisplayMember = "VehiclesID";
            this.VehicleIDcomboBox.FormattingEnabled = true;
            this.VehicleIDcomboBox.Location = new System.Drawing.Point(490, 415);
            this.VehicleIDcomboBox.Name = "VehicleIDcomboBox";
            this.VehicleIDcomboBox.Size = new System.Drawing.Size(121, 28);
            this.VehicleIDcomboBox.TabIndex = 87;
            this.VehicleIDcomboBox.ValueMember = "VehiclesID";
            // 
            // vehiclesBindingSource
            // 
            this.vehiclesBindingSource.DataMember = "Vehicles";
            this.vehiclesBindingSource.DataSource = this.cargo_Management_SystemDataSet;
            // 
            // cargo_Management_SystemDataSet
            // 
            this.cargo_Management_SystemDataSet.DataSetName = "Cargo_Management_SystemDataSet";
            this.cargo_Management_SystemDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // CosttextBox
            // 
            this.CosttextBox.Location = new System.Drawing.Point(334, 489);
            this.CosttextBox.Name = "CosttextBox";
            this.CosttextBox.Size = new System.Drawing.Size(100, 26);
            this.CosttextBox.TabIndex = 86;
            // 
            // DescriptiontextBox
            // 
            this.DescriptiontextBox.Location = new System.Drawing.Point(645, 489);
            this.DescriptiontextBox.Name = "DescriptiontextBox";
            this.DescriptiontextBox.Size = new System.Drawing.Size(226, 26);
            this.DescriptiontextBox.TabIndex = 85;
            // 
            // MaintenancedateTimePicker
            // 
            this.MaintenancedateTimePicker.Location = new System.Drawing.Point(740, 422);
            this.MaintenancedateTimePicker.Name = "MaintenancedateTimePicker";
            this.MaintenancedateTimePicker.Size = new System.Drawing.Size(200, 26);
            this.MaintenancedateTimePicker.TabIndex = 84;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Teal;
            this.label5.Location = new System.Drawing.Point(358, 415);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(105, 25);
            this.label5.TabIndex = 83;
            this.label5.Text = "VehicleID";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Teal;
            this.label4.Location = new System.Drawing.Point(673, 422);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 25);
            this.label4.TabIndex = 82;
            this.label4.Text = "Date";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Teal;
            this.label1.Location = new System.Drawing.Point(248, 492);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 25);
            this.label1.TabIndex = 81;
            this.label1.Text = "Cost";
            // 
            // locnamelabel
            // 
            this.locnamelabel.AutoSize = true;
            this.locnamelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.locnamelabel.ForeColor = System.Drawing.Color.Teal;
            this.locnamelabel.Location = new System.Drawing.Point(491, 492);
            this.locnamelabel.Name = "locnamelabel";
            this.locnamelabel.Size = new System.Drawing.Size(120, 25);
            this.locnamelabel.TabIndex = 80;
            this.locnamelabel.Text = "Description";
            // 
            // ExitMaintananceRecordbutton
            // 
            this.ExitMaintananceRecordbutton.BackColor = System.Drawing.Color.Teal;
            this.ExitMaintananceRecordbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExitMaintananceRecordbutton.ForeColor = System.Drawing.Color.MintCream;
            this.ExitMaintananceRecordbutton.Location = new System.Drawing.Point(800, 550);
            this.ExitMaintananceRecordbutton.Name = "ExitMaintananceRecordbutton";
            this.ExitMaintananceRecordbutton.Size = new System.Drawing.Size(111, 41);
            this.ExitMaintananceRecordbutton.TabIndex = 79;
            this.ExitMaintananceRecordbutton.Text = "Exit";
            this.ExitMaintananceRecordbutton.UseVisualStyleBackColor = false;
            this.ExitMaintananceRecordbutton.Click += new System.EventHandler(this.ExitMaintananceRecordbutton_Click);
            // 
            // DeleteMaintananceRecordbutton
            // 
            this.DeleteMaintananceRecordbutton.BackColor = System.Drawing.Color.Teal;
            this.DeleteMaintananceRecordbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeleteMaintananceRecordbutton.ForeColor = System.Drawing.Color.MintCream;
            this.DeleteMaintananceRecordbutton.Location = new System.Drawing.Point(619, 550);
            this.DeleteMaintananceRecordbutton.Name = "DeleteMaintananceRecordbutton";
            this.DeleteMaintananceRecordbutton.Size = new System.Drawing.Size(111, 41);
            this.DeleteMaintananceRecordbutton.TabIndex = 78;
            this.DeleteMaintananceRecordbutton.Text = "Delete";
            this.DeleteMaintananceRecordbutton.UseVisualStyleBackColor = false;
            this.DeleteMaintananceRecordbutton.Click += new System.EventHandler(this.DeleteMaintananceRecordbutton_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Location = new System.Drawing.Point(0, 378);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1005, 10);
            this.panel1.TabIndex = 77;
            // 
            // MaintenancedataGridView
            // 
            this.MaintenancedataGridView.AutoGenerateColumns = false;
            this.MaintenancedataGridView.BackgroundColor = System.Drawing.Color.MintCream;
            this.MaintenancedataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.MaintenancedataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.recordIDDataGridViewTextBoxColumn,
            this.vehicleIDDataGridViewTextBoxColumn,
            this.dateDataGridViewTextBoxColumn,
            this.descriptionDataGridViewTextBoxColumn,
            this.costDataGridViewTextBoxColumn});
            this.MaintenancedataGridView.DataSource = this.maintenanceRecordsBindingSource;
            this.MaintenancedataGridView.Dock = System.Windows.Forms.DockStyle.Top;
            this.MaintenancedataGridView.GridColor = System.Drawing.Color.Teal;
            this.MaintenancedataGridView.Location = new System.Drawing.Point(0, 101);
            this.MaintenancedataGridView.Name = "MaintenancedataGridView";
            this.MaintenancedataGridView.RowHeadersWidth = 62;
            this.MaintenancedataGridView.RowTemplate.Height = 28;
            this.MaintenancedataGridView.Size = new System.Drawing.Size(1005, 276);
            this.MaintenancedataGridView.TabIndex = 76;
            this.MaintenancedataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.MaintenancedataGridView_CellContentClick);
            // 
            // recordIDDataGridViewTextBoxColumn
            // 
            this.recordIDDataGridViewTextBoxColumn.DataPropertyName = "RecordID";
            this.recordIDDataGridViewTextBoxColumn.HeaderText = "RecordID";
            this.recordIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.recordIDDataGridViewTextBoxColumn.Name = "recordIDDataGridViewTextBoxColumn";
            this.recordIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.recordIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // vehicleIDDataGridViewTextBoxColumn
            // 
            this.vehicleIDDataGridViewTextBoxColumn.DataPropertyName = "VehicleID";
            this.vehicleIDDataGridViewTextBoxColumn.HeaderText = "VehicleID";
            this.vehicleIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.vehicleIDDataGridViewTextBoxColumn.Name = "vehicleIDDataGridViewTextBoxColumn";
            this.vehicleIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // dateDataGridViewTextBoxColumn
            // 
            this.dateDataGridViewTextBoxColumn.DataPropertyName = "Date";
            this.dateDataGridViewTextBoxColumn.HeaderText = "Date";
            this.dateDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.dateDataGridViewTextBoxColumn.Name = "dateDataGridViewTextBoxColumn";
            this.dateDataGridViewTextBoxColumn.Width = 150;
            // 
            // descriptionDataGridViewTextBoxColumn
            // 
            this.descriptionDataGridViewTextBoxColumn.DataPropertyName = "Description";
            this.descriptionDataGridViewTextBoxColumn.HeaderText = "Description";
            this.descriptionDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.descriptionDataGridViewTextBoxColumn.Name = "descriptionDataGridViewTextBoxColumn";
            this.descriptionDataGridViewTextBoxColumn.Width = 150;
            // 
            // costDataGridViewTextBoxColumn
            // 
            this.costDataGridViewTextBoxColumn.DataPropertyName = "Cost";
            this.costDataGridViewTextBoxColumn.HeaderText = "Cost";
            this.costDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.costDataGridViewTextBoxColumn.Name = "costDataGridViewTextBoxColumn";
            this.costDataGridViewTextBoxColumn.Width = 150;
            // 
            // maintenanceRecordsBindingSource
            // 
            this.maintenanceRecordsBindingSource.DataMember = "MaintenanceRecords";
            this.maintenanceRecordsBindingSource.DataSource = this.cargo_Management_SystemDataSet;
            // 
            // warehouseformpanel
            // 
            this.warehouseformpanel.BackColor = System.Drawing.Color.Teal;
            this.warehouseformpanel.Controls.Add(this.MaintenanceRecordFormlabel);
            this.warehouseformpanel.Controls.Add(this.namelabel);
            this.warehouseformpanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.warehouseformpanel.Location = new System.Drawing.Point(0, 0);
            this.warehouseformpanel.Name = "warehouseformpanel";
            this.warehouseformpanel.Size = new System.Drawing.Size(1005, 101);
            this.warehouseformpanel.TabIndex = 75;
            // 
            // MaintenanceRecordFormlabel
            // 
            this.MaintenanceRecordFormlabel.AutoSize = true;
            this.MaintenanceRecordFormlabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaintenanceRecordFormlabel.ForeColor = System.Drawing.Color.MintCream;
            this.MaintenanceRecordFormlabel.Location = new System.Drawing.Point(297, 33);
            this.MaintenanceRecordFormlabel.Name = "MaintenanceRecordFormlabel";
            this.MaintenanceRecordFormlabel.Size = new System.Drawing.Size(351, 42);
            this.MaintenanceRecordFormlabel.TabIndex = 1;
            this.MaintenanceRecordFormlabel.Text = "Maintenance Record";
            // 
            // namelabel
            // 
            this.namelabel.AutoSize = true;
            this.namelabel.ForeColor = System.Drawing.Color.MintCream;
            this.namelabel.Location = new System.Drawing.Point(291, 33);
            this.namelabel.Name = "namelabel";
            this.namelabel.Size = new System.Drawing.Size(0, 20);
            this.namelabel.TabIndex = 0;
            // 
            // maintenanceRecordsTableAdapter
            // 
            this.maintenanceRecordsTableAdapter.ClearBeforeFill = true;
            // 
            // UpdateMaintananceRecordbutton
            // 
            this.UpdateMaintananceRecordbutton.BackColor = System.Drawing.Color.Teal;
            this.UpdateMaintananceRecordbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpdateMaintananceRecordbutton.ForeColor = System.Drawing.Color.MintCream;
            this.UpdateMaintananceRecordbutton.Location = new System.Drawing.Point(454, 550);
            this.UpdateMaintananceRecordbutton.Name = "UpdateMaintananceRecordbutton";
            this.UpdateMaintananceRecordbutton.Size = new System.Drawing.Size(111, 41);
            this.UpdateMaintananceRecordbutton.TabIndex = 88;
            this.UpdateMaintananceRecordbutton.Text = "Update";
            this.UpdateMaintananceRecordbutton.UseVisualStyleBackColor = false;
            this.UpdateMaintananceRecordbutton.Click += new System.EventHandler(this.UpdateMaintananceRecordbutton_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Teal;
            this.label2.Location = new System.Drawing.Point(77, 421);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 25);
            this.label2.TabIndex = 89;
            this.label2.Text = "RecordID";
            // 
            // RecordIDcomboBox
            // 
            this.RecordIDcomboBox.DataSource = this.maintenanceRecordsBindingSource1;
            this.RecordIDcomboBox.DisplayMember = "RecordID";
            this.RecordIDcomboBox.FormattingEnabled = true;
            this.RecordIDcomboBox.Location = new System.Drawing.Point(184, 418);
            this.RecordIDcomboBox.Name = "RecordIDcomboBox";
            this.RecordIDcomboBox.Size = new System.Drawing.Size(121, 28);
            this.RecordIDcomboBox.TabIndex = 90;
            this.RecordIDcomboBox.ValueMember = "RecordID";
            // 
            // maintenanceRecordsBindingSource1
            // 
            this.maintenanceRecordsBindingSource1.DataMember = "MaintenanceRecords";
            this.maintenanceRecordsBindingSource1.DataSource = this.cargo_Management_SystemDataSet;
            // 
            // vehiclesTableAdapter
            // 
            this.vehiclesTableAdapter.ClearBeforeFill = true;
            // 
            // ManageMaintananceRecordForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MintCream;
            this.ClientSize = new System.Drawing.Size(1005, 603);
            this.Controls.Add(this.RecordIDcomboBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.UpdateMaintananceRecordbutton);
            this.Controls.Add(this.VehicleIDcomboBox);
            this.Controls.Add(this.CosttextBox);
            this.Controls.Add(this.DescriptiontextBox);
            this.Controls.Add(this.MaintenancedateTimePicker);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.locnamelabel);
            this.Controls.Add(this.ExitMaintananceRecordbutton);
            this.Controls.Add(this.DeleteMaintananceRecordbutton);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.MaintenancedataGridView);
            this.Controls.Add(this.warehouseformpanel);
            this.Name = "ManageMaintananceRecordForm";
            this.Text = "ManageMaintananceRecordForm";
            this.Load += new System.EventHandler(this.ManageMaintananceRecordForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.vehiclesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cargo_Management_SystemDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MaintenancedataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.maintenanceRecordsBindingSource)).EndInit();
            this.warehouseformpanel.ResumeLayout(false);
            this.warehouseformpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.maintenanceRecordsBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox VehicleIDcomboBox;
        private System.Windows.Forms.TextBox CosttextBox;
        private System.Windows.Forms.TextBox DescriptiontextBox;
        private System.Windows.Forms.DateTimePicker MaintenancedateTimePicker;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label locnamelabel;
        private System.Windows.Forms.Button ExitMaintananceRecordbutton;
        private System.Windows.Forms.Button DeleteMaintananceRecordbutton;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView MaintenancedataGridView;
        private System.Windows.Forms.Panel warehouseformpanel;
        private System.Windows.Forms.Label MaintenanceRecordFormlabel;
        private System.Windows.Forms.Label namelabel;
        private Cargo_Management_SystemDataSet cargo_Management_SystemDataSet;
        private System.Windows.Forms.BindingSource maintenanceRecordsBindingSource;
        private Cargo_Management_SystemDataSetTableAdapters.MaintenanceRecordsTableAdapter maintenanceRecordsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn recordIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn vehicleIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn descriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn costDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button UpdateMaintananceRecordbutton;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox RecordIDcomboBox;
        private System.Windows.Forms.BindingSource maintenanceRecordsBindingSource1;
        private System.Windows.Forms.BindingSource vehiclesBindingSource;
        private Cargo_Management_SystemDataSetTableAdapters.VehiclesTableAdapter vehiclesTableAdapter;
    }
}