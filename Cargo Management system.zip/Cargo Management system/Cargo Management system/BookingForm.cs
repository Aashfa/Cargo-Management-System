﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cargo_Management_system
{
    public partial class BookingForm : Form
    {
        public BookingForm()
        {
            InitializeComponent();
        }

        private void DescriptiontextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void Nextbutton_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-04KFGU9\\SQLSERVER2022;Initial Catalog=\"Cargo Management System\";Integrated Security=True;Encrypt=False"; 

            string insertQuery = @"INSERT INTO Cargo (WarehouseID, ClientID, Description, Weight, Dimensions, SpecialRequirements, Status)
                                   VALUES (@WarehouseID, @ClientID, @Description, @Weight, @Dimensions, @SpecialRequirements, @Status)";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(insertQuery, con))
                {
                   
                    cmd.Parameters.AddWithValue("@WarehouseID", WarehouseIDcomboBox.Text); 
                    cmd.Parameters.AddWithValue("@ClientID", ClientIDcomboBox.Text); 
                    cmd.Parameters.AddWithValue("@Description", DescriptiontextBox.Text);
                    cmd.Parameters.AddWithValue("@Weight", WeighttextBox.Text); 
                    cmd.Parameters.AddWithValue("@Dimensions", WeighttextBox.Text); 
                    cmd.Parameters.AddWithValue("@SpecialRequirements", SpecialRequirementstextBox.Text); 
                    cmd.Parameters.AddWithValue("@Status", "Booked"); 

                    try
                    {
                        con.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        con.Close();

                        // Show a success message if rowsAffected is greater than 0
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Cargo record registered successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("No cargo record registered ", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    catch (Exception ex)
                    {
                        // Show an error message
                        MessageBox.Show($"Error in registering cargo record: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            this.Close();
      
        }

        private void BookingForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'cargo_Management_SystemDataSet.Warehouse' table. 
            this.warehouseTableAdapter.Fill(this.cargo_Management_SystemDataSet.Warehouse);
            // TODO: This line of code loads data into the 'cargo_Management_SystemDataSet.Clients' table. 
            this.clientsTableAdapter.Fill(this.cargo_Management_SystemDataSet.Clients);

        }

        private void Exitbutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
