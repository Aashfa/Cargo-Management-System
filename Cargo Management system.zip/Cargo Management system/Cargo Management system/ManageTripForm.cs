﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cargo_Management_system
{
    public partial class ManageTripForm : Form
    {
        public ManageTripForm()
        {
            InitializeComponent();
        }

        private void ManageTripForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'cargo_Management_SystemDataSet.Trips' table. You can move, or remove it, as needed.
            this.tripsTableAdapter.Fill(this.cargo_Management_SystemDataSet.Trips);

        }

        private void Exitbutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Updatebutton_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-04KFGU9\\SQLSERVER2022;Initial Catalog=\"Cargo Management System\";Integrated Security=True;Encrypt=False"; 

            string updateQuery = @"UPDATE Trips SET CargoID = @CargoID,VehicleID = @VehicleID,DriverID = @DriverID,StartDate = @StartDate,
                                  EndDate = @EndDate,Origin = @Origin,Destination = @Destination,Status = @Status WHERE TripID = @TripID"; 

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(updateQuery, con))
                {
                   
                    cmd.Parameters.AddWithValue("@CargoID", CargoIDcomboBox.Text); 
                    cmd.Parameters.AddWithValue("@VehicleID", VehicleIDcomboBox.Text); 
                    cmd.Parameters.AddWithValue("@DriverID", DriverIDcomboBox.Text); 
                    cmd.Parameters.AddWithValue("@StartDate", DateTime.Parse(StartdateTimePicker.Text)); 
                    cmd.Parameters.AddWithValue("@EndDate", DateTime.Parse(EnddateTimePicker.Text)); 
                    cmd.Parameters.AddWithValue("@Origin", OrigincomboBox.Text); 
                    cmd.Parameters.AddWithValue("@Destination", DestinationcomboBox.Text); 
                    cmd.Parameters.AddWithValue("@Status", StatuscomboBox.Text);
                    cmd.Parameters.AddWithValue("@TripID", TripIDcomboBox.Text); 

                    try
                    {
                        con.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        MessageBox.Show(rowsAffected > 0 ? "Data updated successfully!" : "No record found with the provided TripID.");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
            this.Close();

        }

        private void Deletebutton_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-04KFGU9\\SQLSERVER2022;Initial Catalog=\"Cargo Management System\";Integrated Security=True;Encrypt=False"; 

            string deleteQuery = @"
DELETE FROM Trips
WHERE TripID = @TripID";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(deleteQuery, con))
                {
                    
                    cmd.Parameters.AddWithValue("@TripID", TripIDcomboBox.Text);

                    try
                    {
                        con.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            // Show a success message
                            Console.WriteLine("Trip data deleted successfully!");
                        }
                        else
                        {
                            // Show a message if no rows were affected (TripID not found)
                            Console.WriteLine("No matching TripID found for deletion.");
                        }
                    }
                    catch (Exception ex)
                    {
                        // Show an error message
                        Console.WriteLine($"Error deleting data: {ex.Message}");
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
            this.Close();

        }

        private void MVdataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                TripIDcomboBox.Text = TripsDataGridView.Rows[e.RowIndex].Cells[0].Value.ToString();
                CargoIDcomboBox.Text = TripsDataGridView.Rows[e.RowIndex].Cells[1].Value.ToString();
                VehicleIDcomboBox.Text = TripsDataGridView.Rows[e.RowIndex].Cells[2].Value.ToString();
                DriverIDcomboBox.Text = TripsDataGridView.Rows[e.RowIndex].Cells[3].Value.ToString();
                StartdateTimePicker.Text = TripsDataGridView.Rows[e.RowIndex].Cells[4].Value.ToString();
                EnddateTimePicker.Text = TripsDataGridView.Rows[e.RowIndex].Cells[5].Value.ToString();
                OrigincomboBox.Text = TripsDataGridView.Rows[e.RowIndex].Cells[6].Value.ToString();
                DestinationcomboBox.Text = TripsDataGridView.Rows[e.RowIndex].Cells[7].Value.ToString();
                StatuscomboBox.Text = TripsDataGridView.Rows[e.RowIndex].Cells[8].Value.ToString();
            }

        }

        private void EnddateTimePicker_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
