﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cargo_Management_system
{
    public partial class ScheduledTripForm : Form
    {
        public ScheduledTripForm()
        {
            InitializeComponent();
        }

        private void ScheduledTripForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'cargo_Management_SystemDataSet.Drivers' table. You can move, or remove it, as needed.
            this.driversTableAdapter.Fill(this.cargo_Management_SystemDataSet.Drivers);
            // TODO: This line of code loads data into the 'cargo_Management_SystemDataSet.Cargo' table. You can move, or remove it, as needed.
            this.cargoTableAdapter.Fill(this.cargo_Management_SystemDataSet.Cargo);
            // TODO: This line of code loads data into the 'cargo_Management_SystemDataSet.Vehicles' table. You can move, or remove it, as needed.
            this.vehiclesTableAdapter.Fill(this.cargo_Management_SystemDataSet.Vehicles);
            // TODO: This line of code loads data into the 'cargo_Management_SystemDataSet.Trips' table. You can move, or remove it, as needed.
            this.tripsTableAdapter.Fill(this.cargo_Management_SystemDataSet.Trips);

        }

        private void MVdataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Exitbutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void AddScheduledTripbutton_Click(object sender, EventArgs e)
        {

        }

        private void UpdateTripbutton_Click(object sender, EventArgs e)
        {

        }

        private void AddScheduledTripbutton_Click_1(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-04KFGU9\\SQLSERVER2022;Initial Catalog=\"Cargo Management System\";Integrated Security=True;Encrypt=False"; 

            string insertQuery = @"
INSERT INTO Trips (CargoID, VehicleID, DriverID, StartDate, EndDate, Origin, Destination, Status)
VALUES (@CargoID, @VehicleID, @DriverID, @StartDate, @EndDate, @Origin, @Destination, @Status)";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(insertQuery, con))
                {
                   
                    cmd.Parameters.AddWithValue("@CargoID", CargoIDcomboBox.Text); 
                    cmd.Parameters.AddWithValue("@VehicleID", VehicleIDcomboBox.Text); 
                    cmd.Parameters.AddWithValue("@DriverID", DriverIDcomboBox.Text); 
                    cmd.Parameters.AddWithValue("@StartDate", DateTime.Parse(StartdateTimePicker.Text)); 
                    cmd.Parameters.AddWithValue("@EndDate", DateTime.Parse( EnddateTimePicker.Text));
                    cmd.Parameters.AddWithValue("@Origin", OrigincomboBox.Text); 
                    cmd.Parameters.AddWithValue("@Destination", DestinationcomboBox.Text); 
                    cmd.Parameters.AddWithValue("@Status", StatuscomboBox.Text); 

                    try
                    {
                        con.Open();
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Data inserted successfully!");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
            this.Close();

        }
    }
}
