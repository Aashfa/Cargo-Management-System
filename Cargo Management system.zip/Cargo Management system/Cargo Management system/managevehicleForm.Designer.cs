﻿namespace Cargo_Management_system
{
    partial class managevehicleForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.veichleregformpanel = new System.Windows.Forms.Panel();
            this.Form1label = new System.Windows.Forms.Label();
            this.namelabel = new System.Windows.Forms.Label();
            this.Vdeletebutton = new System.Windows.Forms.Button();
            this.VUpdatebutton = new System.Windows.Forms.Button();
            this.Vidlabel = new System.Windows.Forms.Label();
            this.VRExitbutton = new System.Windows.Forms.Button();
            this.VMalabel = new System.Windows.Forms.Label();
            this.VMolabel = new System.Windows.Forms.Label();
            this.VYlabel = new System.Windows.Forms.Label();
            this.VSlabel = new System.Windows.Forms.Label();
            this.VClabel = new System.Windows.Forms.Label();
            this.VTlabel = new System.Windows.Forms.Label();
            this.MVdataGridView = new System.Windows.Forms.DataGridView();
            this.vehiclesIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.makeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.modelDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.yearDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.capacityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.veichleTypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vehiclesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cargo_Management_SystemDataSet = new Cargo_Management_system.Cargo_Management_SystemDataSet();
            this.vehiclesTableAdapter = new Cargo_Management_system.Cargo_Management_SystemDataSetTableAdapters.VehiclesTableAdapter();
            this.VehicleMaketextBox = new System.Windows.Forms.TextBox();
            this.VehicleTypetextBox = new System.Windows.Forms.TextBox();
            this.VehicleCapacitytextBox = new System.Windows.Forms.TextBox();
            this.VehicleYeartextBox = new System.Windows.Forms.TextBox();
            this.VehicleModeltextBox = new System.Windows.Forms.TextBox();
            this.VehicleStatuscomboobx = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.VeichleIDcomboBox = new System.Windows.Forms.ComboBox();
            this.vehiclesBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.veichleregformpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MVdataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vehiclesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cargo_Management_SystemDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vehiclesBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // veichleregformpanel
            // 
            this.veichleregformpanel.BackColor = System.Drawing.Color.Teal;
            this.veichleregformpanel.Controls.Add(this.Form1label);
            this.veichleregformpanel.Controls.Add(this.namelabel);
            this.veichleregformpanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.veichleregformpanel.Location = new System.Drawing.Point(0, 0);
            this.veichleregformpanel.Name = "veichleregformpanel";
            this.veichleregformpanel.Size = new System.Drawing.Size(1005, 101);
            this.veichleregformpanel.TabIndex = 4;
            // 
            // Form1label
            // 
            this.Form1label.AutoSize = true;
            this.Form1label.Font = new System.Drawing.Font("Microsoft YaHei UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Form1label.ForeColor = System.Drawing.Color.MintCream;
            this.Form1label.Location = new System.Drawing.Point(320, 33);
            this.Form1label.Name = "Form1label";
            this.Form1label.Size = new System.Drawing.Size(285, 42);
            this.Form1label.TabIndex = 1;
            this.Form1label.Text = "Manage Vehicle ";
            // 
            // namelabel
            // 
            this.namelabel.AutoSize = true;
            this.namelabel.ForeColor = System.Drawing.Color.MintCream;
            this.namelabel.Location = new System.Drawing.Point(291, 33);
            this.namelabel.Name = "namelabel";
            this.namelabel.Size = new System.Drawing.Size(0, 20);
            this.namelabel.TabIndex = 0;
            // 
            // Vdeletebutton
            // 
            this.Vdeletebutton.BackColor = System.Drawing.Color.Teal;
            this.Vdeletebutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Vdeletebutton.ForeColor = System.Drawing.Color.MintCream;
            this.Vdeletebutton.Location = new System.Drawing.Point(706, 550);
            this.Vdeletebutton.Name = "Vdeletebutton";
            this.Vdeletebutton.Size = new System.Drawing.Size(115, 41);
            this.Vdeletebutton.TabIndex = 22;
            this.Vdeletebutton.Text = "Delete";
            this.Vdeletebutton.UseVisualStyleBackColor = false;
            this.Vdeletebutton.Click += new System.EventHandler(this.Vdeletebutton_Click);
            // 
            // VUpdatebutton
            // 
            this.VUpdatebutton.BackColor = System.Drawing.Color.Teal;
            this.VUpdatebutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VUpdatebutton.ForeColor = System.Drawing.Color.MintCream;
            this.VUpdatebutton.Location = new System.Drawing.Point(564, 550);
            this.VUpdatebutton.Name = "VUpdatebutton";
            this.VUpdatebutton.Size = new System.Drawing.Size(119, 41);
            this.VUpdatebutton.TabIndex = 23;
            this.VUpdatebutton.Text = "Update";
            this.VUpdatebutton.UseVisualStyleBackColor = false;
            this.VUpdatebutton.Click += new System.EventHandler(this.VUpdatebutton_Click);
            // 
            // Vidlabel
            // 
            this.Vidlabel.AutoSize = true;
            this.Vidlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Vidlabel.ForeColor = System.Drawing.Color.Teal;
            this.Vidlabel.Location = new System.Drawing.Point(91, 396);
            this.Vidlabel.Name = "Vidlabel";
            this.Vidlabel.Size = new System.Drawing.Size(33, 25);
            this.Vidlabel.TabIndex = 24;
            this.Vidlabel.Text = "ID";
            // 
            // VRExitbutton
            // 
            this.VRExitbutton.BackColor = System.Drawing.Color.Teal;
            this.VRExitbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VRExitbutton.ForeColor = System.Drawing.Color.MintCream;
            this.VRExitbutton.Location = new System.Drawing.Point(847, 550);
            this.VRExitbutton.Name = "VRExitbutton";
            this.VRExitbutton.Size = new System.Drawing.Size(111, 41);
            this.VRExitbutton.TabIndex = 25;
            this.VRExitbutton.Text = "Exit";
            this.VRExitbutton.UseVisualStyleBackColor = false;
            this.VRExitbutton.Click += new System.EventHandler(this.VRExitbutton_Click);
            // 
            // VMalabel
            // 
            this.VMalabel.AutoSize = true;
            this.VMalabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VMalabel.ForeColor = System.Drawing.Color.Teal;
            this.VMalabel.Location = new System.Drawing.Point(309, 394);
            this.VMalabel.Name = "VMalabel";
            this.VMalabel.Size = new System.Drawing.Size(65, 25);
            this.VMalabel.TabIndex = 27;
            this.VMalabel.Text = "Make";
            // 
            // VMolabel
            // 
            this.VMolabel.AutoSize = true;
            this.VMolabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VMolabel.ForeColor = System.Drawing.Color.Teal;
            this.VMolabel.Location = new System.Drawing.Point(534, 394);
            this.VMolabel.Name = "VMolabel";
            this.VMolabel.Size = new System.Drawing.Size(71, 25);
            this.VMolabel.TabIndex = 28;
            this.VMolabel.Text = "Model";
            // 
            // VYlabel
            // 
            this.VYlabel.AutoSize = true;
            this.VYlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VYlabel.ForeColor = System.Drawing.Color.Teal;
            this.VYlabel.Location = new System.Drawing.Point(764, 393);
            this.VYlabel.Name = "VYlabel";
            this.VYlabel.Size = new System.Drawing.Size(57, 25);
            this.VYlabel.TabIndex = 29;
            this.VYlabel.Text = "Year";
            // 
            // VSlabel
            // 
            this.VSlabel.AutoSize = true;
            this.VSlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VSlabel.ForeColor = System.Drawing.Color.Teal;
            this.VSlabel.Location = new System.Drawing.Point(372, 461);
            this.VSlabel.Name = "VSlabel";
            this.VSlabel.Size = new System.Drawing.Size(74, 25);
            this.VSlabel.TabIndex = 30;
            this.VSlabel.Text = "Status";
            // 
            // VClabel
            // 
            this.VClabel.AutoSize = true;
            this.VClabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VClabel.ForeColor = System.Drawing.Color.Teal;
            this.VClabel.Location = new System.Drawing.Point(614, 460);
            this.VClabel.Name = "VClabel";
            this.VClabel.Size = new System.Drawing.Size(97, 25);
            this.VClabel.TabIndex = 31;
            this.VClabel.Text = "Capacity";
            // 
            // VTlabel
            // 
            this.VTlabel.AutoSize = true;
            this.VTlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VTlabel.ForeColor = System.Drawing.Color.Teal;
            this.VTlabel.Location = new System.Drawing.Point(152, 463);
            this.VTlabel.Name = "VTlabel";
            this.VTlabel.Size = new System.Drawing.Size(61, 25);
            this.VTlabel.TabIndex = 32;
            this.VTlabel.Text = "Type";
            // 
            // MVdataGridView
            // 
            this.MVdataGridView.AutoGenerateColumns = false;
            this.MVdataGridView.BackgroundColor = System.Drawing.Color.MintCream;
            this.MVdataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.MVdataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.vehiclesIDDataGridViewTextBoxColumn,
            this.makeDataGridViewTextBoxColumn,
            this.modelDataGridViewTextBoxColumn,
            this.yearDataGridViewTextBoxColumn,
            this.statusDataGridViewTextBoxColumn,
            this.capacityDataGridViewTextBoxColumn,
            this.veichleTypeDataGridViewTextBoxColumn});
            this.MVdataGridView.DataSource = this.vehiclesBindingSource;
            this.MVdataGridView.Dock = System.Windows.Forms.DockStyle.Top;
            this.MVdataGridView.GridColor = System.Drawing.Color.Teal;
            this.MVdataGridView.Location = new System.Drawing.Point(0, 101);
            this.MVdataGridView.Name = "MVdataGridView";
            this.MVdataGridView.RowHeadersWidth = 62;
            this.MVdataGridView.RowTemplate.Height = 28;
            this.MVdataGridView.Size = new System.Drawing.Size(1005, 268);
            this.MVdataGridView.TabIndex = 33;
            this.MVdataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.MVdataGridView_CellContentClick);
            // 
            // vehiclesIDDataGridViewTextBoxColumn
            // 
            this.vehiclesIDDataGridViewTextBoxColumn.DataPropertyName = "VehiclesID";
            this.vehiclesIDDataGridViewTextBoxColumn.HeaderText = "VehiclesID";
            this.vehiclesIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.vehiclesIDDataGridViewTextBoxColumn.Name = "vehiclesIDDataGridViewTextBoxColumn";
            this.vehiclesIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.vehiclesIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // makeDataGridViewTextBoxColumn
            // 
            this.makeDataGridViewTextBoxColumn.DataPropertyName = "Make";
            this.makeDataGridViewTextBoxColumn.HeaderText = "Make";
            this.makeDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.makeDataGridViewTextBoxColumn.Name = "makeDataGridViewTextBoxColumn";
            this.makeDataGridViewTextBoxColumn.Width = 150;
            // 
            // modelDataGridViewTextBoxColumn
            // 
            this.modelDataGridViewTextBoxColumn.DataPropertyName = "Model";
            this.modelDataGridViewTextBoxColumn.HeaderText = "Model";
            this.modelDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.modelDataGridViewTextBoxColumn.Name = "modelDataGridViewTextBoxColumn";
            this.modelDataGridViewTextBoxColumn.Width = 150;
            // 
            // yearDataGridViewTextBoxColumn
            // 
            this.yearDataGridViewTextBoxColumn.DataPropertyName = "Year";
            this.yearDataGridViewTextBoxColumn.HeaderText = "Year";
            this.yearDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.yearDataGridViewTextBoxColumn.Name = "yearDataGridViewTextBoxColumn";
            this.yearDataGridViewTextBoxColumn.Width = 150;
            // 
            // statusDataGridViewTextBoxColumn
            // 
            this.statusDataGridViewTextBoxColumn.DataPropertyName = "Status";
            this.statusDataGridViewTextBoxColumn.HeaderText = "Status";
            this.statusDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.statusDataGridViewTextBoxColumn.Name = "statusDataGridViewTextBoxColumn";
            this.statusDataGridViewTextBoxColumn.Width = 150;
            // 
            // capacityDataGridViewTextBoxColumn
            // 
            this.capacityDataGridViewTextBoxColumn.DataPropertyName = "Capacity";
            this.capacityDataGridViewTextBoxColumn.HeaderText = "Capacity";
            this.capacityDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.capacityDataGridViewTextBoxColumn.Name = "capacityDataGridViewTextBoxColumn";
            this.capacityDataGridViewTextBoxColumn.Width = 150;
            // 
            // veichleTypeDataGridViewTextBoxColumn
            // 
            this.veichleTypeDataGridViewTextBoxColumn.DataPropertyName = "VeichleType";
            this.veichleTypeDataGridViewTextBoxColumn.HeaderText = "VeichleType";
            this.veichleTypeDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.veichleTypeDataGridViewTextBoxColumn.Name = "veichleTypeDataGridViewTextBoxColumn";
            this.veichleTypeDataGridViewTextBoxColumn.Width = 150;
            // 
            // vehiclesBindingSource
            // 
            this.vehiclesBindingSource.DataMember = "Vehicles";
            this.vehiclesBindingSource.DataSource = this.cargo_Management_SystemDataSet;
            // 
            // cargo_Management_SystemDataSet
            // 
            this.cargo_Management_SystemDataSet.DataSetName = "Cargo_Management_SystemDataSet";
            this.cargo_Management_SystemDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // vehiclesTableAdapter
            // 
            this.vehiclesTableAdapter.ClearBeforeFill = true;
            // 
            // VehicleMaketextBox
            // 
            this.VehicleMaketextBox.Location = new System.Drawing.Point(386, 394);
            this.VehicleMaketextBox.Name = "VehicleMaketextBox";
            this.VehicleMaketextBox.Size = new System.Drawing.Size(100, 26);
            this.VehicleMaketextBox.TabIndex = 34;
            // 
            // VehicleTypetextBox
            // 
            this.VehicleTypetextBox.Location = new System.Drawing.Point(219, 462);
            this.VehicleTypetextBox.Name = "VehicleTypetextBox";
            this.VehicleTypetextBox.Size = new System.Drawing.Size(100, 26);
            this.VehicleTypetextBox.TabIndex = 36;
            // 
            // VehicleCapacitytextBox
            // 
            this.VehicleCapacitytextBox.Location = new System.Drawing.Point(721, 459);
            this.VehicleCapacitytextBox.Name = "VehicleCapacitytextBox";
            this.VehicleCapacitytextBox.Size = new System.Drawing.Size(100, 26);
            this.VehicleCapacitytextBox.TabIndex = 38;
            // 
            // VehicleYeartextBox
            // 
            this.VehicleYeartextBox.Location = new System.Drawing.Point(827, 393);
            this.VehicleYeartextBox.Name = "VehicleYeartextBox";
            this.VehicleYeartextBox.Size = new System.Drawing.Size(100, 26);
            this.VehicleYeartextBox.TabIndex = 39;
            // 
            // VehicleModeltextBox
            // 
            this.VehicleModeltextBox.Location = new System.Drawing.Point(611, 393);
            this.VehicleModeltextBox.Name = "VehicleModeltextBox";
            this.VehicleModeltextBox.Size = new System.Drawing.Size(100, 26);
            this.VehicleModeltextBox.TabIndex = 40;
            // 
            // VehicleStatuscomboobx
            // 
            this.VehicleStatuscomboobx.FormattingEnabled = true;
            this.VehicleStatuscomboobx.Items.AddRange(new object[] {
            "Free",
            "Active",
            "Maintenance",
            "Retired"});
            this.VehicleStatuscomboobx.Location = new System.Drawing.Point(452, 457);
            this.VehicleStatuscomboobx.Name = "VehicleStatuscomboobx";
            this.VehicleStatuscomboobx.Size = new System.Drawing.Size(132, 28);
            this.VehicleStatuscomboobx.TabIndex = 41;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Location = new System.Drawing.Point(0, 368);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1005, 10);
            this.panel1.TabIndex = 42;
            // 
            // VeichleIDcomboBox
            // 
            this.VeichleIDcomboBox.DataSource = this.vehiclesBindingSource1;
            this.VeichleIDcomboBox.DisplayMember = "VehiclesID";
            this.VeichleIDcomboBox.FormattingEnabled = true;
            this.VeichleIDcomboBox.Location = new System.Drawing.Point(143, 393);
            this.VeichleIDcomboBox.Name = "VeichleIDcomboBox";
            this.VeichleIDcomboBox.Size = new System.Drawing.Size(132, 28);
            this.VeichleIDcomboBox.TabIndex = 43;
            this.VeichleIDcomboBox.ValueMember = "VehiclesID";
            // 
            // vehiclesBindingSource1
            // 
            this.vehiclesBindingSource1.DataMember = "Vehicles";
            this.vehiclesBindingSource1.DataSource = this.cargo_Management_SystemDataSet;
            // 
            // managevehicleForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MintCream;
            this.ClientSize = new System.Drawing.Size(1005, 603);
            this.Controls.Add(this.VeichleIDcomboBox);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.VehicleStatuscomboobx);
            this.Controls.Add(this.VehicleModeltextBox);
            this.Controls.Add(this.VehicleYeartextBox);
            this.Controls.Add(this.VehicleCapacitytextBox);
            this.Controls.Add(this.VehicleTypetextBox);
            this.Controls.Add(this.VehicleMaketextBox);
            this.Controls.Add(this.MVdataGridView);
            this.Controls.Add(this.VTlabel);
            this.Controls.Add(this.VClabel);
            this.Controls.Add(this.VSlabel);
            this.Controls.Add(this.VYlabel);
            this.Controls.Add(this.VMolabel);
            this.Controls.Add(this.VMalabel);
            this.Controls.Add(this.VRExitbutton);
            this.Controls.Add(this.Vdeletebutton);
            this.Controls.Add(this.VUpdatebutton);
            this.Controls.Add(this.Vidlabel);
            this.Controls.Add(this.veichleregformpanel);
            this.Name = "managevehicleForm";
            this.Text = "managevehicleForm";
            this.Load += new System.EventHandler(this.manageveicleForm_Load);
            this.veichleregformpanel.ResumeLayout(false);
            this.veichleregformpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MVdataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vehiclesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cargo_Management_SystemDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vehiclesBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel veichleregformpanel;
        private System.Windows.Forms.Label Form1label;
        private System.Windows.Forms.Label namelabel;
        private System.Windows.Forms.Button Vdeletebutton;
        private System.Windows.Forms.Button VUpdatebutton;
        private System.Windows.Forms.Label Vidlabel;
        private System.Windows.Forms.Button VRExitbutton;
        private System.Windows.Forms.Label VMalabel;
        private System.Windows.Forms.Label VMolabel;
        private System.Windows.Forms.Label VYlabel;
        private System.Windows.Forms.Label VSlabel;
        private System.Windows.Forms.Label VClabel;
        private System.Windows.Forms.Label VTlabel;
        private System.Windows.Forms.DataGridView MVdataGridView;
        private Cargo_Management_SystemDataSet cargo_Management_SystemDataSet;
        private System.Windows.Forms.BindingSource vehiclesBindingSource;
        private Cargo_Management_SystemDataSetTableAdapters.VehiclesTableAdapter vehiclesTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn vehiclesIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn makeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn modelDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn yearDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn statusDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn capacityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn veichleTypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.TextBox VehicleMaketextBox;
        private System.Windows.Forms.TextBox VehicleTypetextBox;
        private System.Windows.Forms.TextBox VehicleCapacitytextBox;
        private System.Windows.Forms.TextBox VehicleYeartextBox;
        private System.Windows.Forms.TextBox VehicleModeltextBox;
        private System.Windows.Forms.ComboBox VehicleStatuscomboobx;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox VeichleIDcomboBox;
        private System.Windows.Forms.BindingSource vehiclesBindingSource1;
    }
}