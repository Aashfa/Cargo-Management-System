﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cargo_Management_system
{
    public partial class ManageDriverForm : Form
    {
        public ManageDriverForm()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void ManageDriverForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'cargo_Management_SystemDataSet.Drivers' table. You can move, or remove it, as needed.
            this.driversTableAdapter.Fill(this.cargo_Management_SystemDataSet.Drivers);

        }

        private void VRExitbutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void VUpdatebutton_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-04KFGU9\\SQLSERVER2022;Initial Catalog=\"Cargo Management System\";Integrated Security=True;Encrypt=False";

            string updateDriverQuery = @"UPDATE Drivers SET FirstName = @FirstName,LastName = @LastName,LicenseNumber = @LicenseNumber,LicenseExpiryDate = @LicenseExpiryDate,
                                       Status = @Status,Certification = @Certification WHERE DriverID = @DriverID";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(updateDriverQuery, con))
                {
                    cmd.Parameters.AddWithValue("@DriverID", int.Parse(DriverIDcomboBox.Text)); 
                    cmd.Parameters.AddWithValue("@FirstName", DriverFirstNametextBox.Text);
                    cmd.Parameters.AddWithValue("@LastName", DriverLastNametextBox.Text);
                    cmd.Parameters.AddWithValue("@LicenseNumber", DriverLicenseNotextBox.Text);
                    cmd.Parameters.AddWithValue("@LicenseExpiryDate", DateTime.Parse(DriverLicencedateTimePicker.Text)); 
                    cmd.Parameters.AddWithValue("@Status", DriverStatuscombobox.Text); 
                    cmd.Parameters.AddWithValue("@Certification", DriverCertificationtextBox.Text);

                    try
                    {
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();

                        // Show a success message
                        MessageBox.Show("Driver data updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        // Show an error message
                        MessageBox.Show($"Error updating driver data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            this.Close();

        }

        private void MVdataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DriverIDcomboBox.Text = DriversDataGridView.Rows[e.RowIndex].Cells[0].Value.ToString();
                DriverFirstNametextBox.Text = DriversDataGridView.Rows[e.RowIndex].Cells[1].Value.ToString();
                DriverLastNametextBox.Text = DriversDataGridView.Rows[e.RowIndex].Cells[2].Value.ToString();
                DriverLicenseNotextBox.Text = DriversDataGridView.Rows[e.RowIndex].Cells[3].Value.ToString();
                DriverLicencedateTimePicker.Text = DriversDataGridView.Rows[e.RowIndex].Cells[4].Value.ToString();
                DriverStatuscombobox.Text = DriversDataGridView.Rows[e.RowIndex].Cells[5].Value.ToString();
                DriverCertificationtextBox.Text = DriversDataGridView.Rows[e.RowIndex].Cells[6].Value.ToString();
            }

        }

        private void Vdeletebutton_Click(object sender, EventArgs e)
        {
            string deleteDriverQuery = @"DELETE FROM Drivers WHERE DriverID = @DriverID";

            using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-04KFGU9\\SQLSERVER2022;Initial Catalog=\"Cargo Management System\";Integrated Security=True;Encrypt=False"))
            {
                using (SqlCommand cmd = new SqlCommand(deleteDriverQuery, con))
                {
                    cmd.Parameters.AddWithValue("@DriverID", int.Parse(DriverIDcomboBox.Text)); 

                    try
                    {
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();

                        // Show a success message
                        MessageBox.Show("Driver data deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        // Show an error message
                        MessageBox.Show($"Error deleting driver data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            this.Close();

        }
    }
}
