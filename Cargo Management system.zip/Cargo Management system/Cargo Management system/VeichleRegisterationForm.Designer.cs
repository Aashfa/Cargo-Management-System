﻿namespace Cargo_Management_system
{
    partial class VeichleRegisterationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.veichleregformpanel = new System.Windows.Forms.Panel();
            this.Form1label = new System.Windows.Forms.Label();
            this.namelabel = new System.Windows.Forms.Label();
            this.VRdataGridView = new System.Windows.Forms.DataGridView();
            this.vehiclesIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.makeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.modelDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.yearDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.capacityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.veichleTypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vehiclesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cargo_Management_SystemDataSet = new Cargo_Management_system.Cargo_Management_SystemDataSet();
            this.VMalabel = new System.Windows.Forms.Label();
            this.VYlabel = new System.Windows.Forms.Label();
            this.VClabel = new System.Windows.Forms.Label();
            this.VSlabel = new System.Windows.Forms.Label();
            this.VMolabel = new System.Windows.Forms.Label();
            this.VTlabel = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.VTtextBox = new System.Windows.Forms.TextBox();
            this.VYtextBox = new System.Windows.Forms.TextBox();
            this.VMotextBox = new System.Windows.Forms.TextBox();
            this.VMatextBox = new System.Windows.Forms.TextBox();
            this.VCtextBox = new System.Windows.Forms.TextBox();
            this.Vinsertbutton = new System.Windows.Forms.Button();
            this.VRExitbutton = new System.Windows.Forms.Button();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.freeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.activeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.maintenanceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.retiredToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.VRstatuscomboobx = new System.Windows.Forms.ComboBox();
            this.vehiclesTableAdapter = new Cargo_Management_system.Cargo_Management_SystemDataSetTableAdapters.VehiclesTableAdapter();
            this.panel1 = new System.Windows.Forms.Panel();
            this.veichleregformpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.VRdataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vehiclesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cargo_Management_SystemDataSet)).BeginInit();
            this.contextMenuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // veichleregformpanel
            // 
            this.veichleregformpanel.BackColor = System.Drawing.Color.Teal;
            this.veichleregformpanel.Controls.Add(this.Form1label);
            this.veichleregformpanel.Controls.Add(this.namelabel);
            this.veichleregformpanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.veichleregformpanel.Location = new System.Drawing.Point(0, 0);
            this.veichleregformpanel.Name = "veichleregformpanel";
            this.veichleregformpanel.Size = new System.Drawing.Size(1005, 101);
            this.veichleregformpanel.TabIndex = 3;
            // 
            // Form1label
            // 
            this.Form1label.AutoSize = true;
            this.Form1label.Font = new System.Drawing.Font("Microsoft YaHei UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Form1label.ForeColor = System.Drawing.Color.MintCream;
            this.Form1label.Location = new System.Drawing.Point(320, 33);
            this.Form1label.Name = "Form1label";
            this.Form1label.Size = new System.Drawing.Size(341, 42);
            this.Form1label.TabIndex = 1;
            this.Form1label.Text = "Vehicle Registration";
            // 
            // namelabel
            // 
            this.namelabel.AutoSize = true;
            this.namelabel.ForeColor = System.Drawing.Color.MintCream;
            this.namelabel.Location = new System.Drawing.Point(291, 33);
            this.namelabel.Name = "namelabel";
            this.namelabel.Size = new System.Drawing.Size(0, 20);
            this.namelabel.TabIndex = 0;
            // 
            // VRdataGridView
            // 
            this.VRdataGridView.AutoGenerateColumns = false;
            this.VRdataGridView.BackgroundColor = System.Drawing.Color.MintCream;
            this.VRdataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.VRdataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.vehiclesIDDataGridViewTextBoxColumn,
            this.makeDataGridViewTextBoxColumn,
            this.modelDataGridViewTextBoxColumn,
            this.yearDataGridViewTextBoxColumn,
            this.statusDataGridViewTextBoxColumn,
            this.capacityDataGridViewTextBoxColumn,
            this.veichleTypeDataGridViewTextBoxColumn});
            this.VRdataGridView.DataSource = this.vehiclesBindingSource;
            this.VRdataGridView.GridColor = System.Drawing.Color.Teal;
            this.VRdataGridView.Location = new System.Drawing.Point(0, 99);
            this.VRdataGridView.Name = "VRdataGridView";
            this.VRdataGridView.RowHeadersWidth = 62;
            this.VRdataGridView.RowTemplate.Height = 28;
            this.VRdataGridView.Size = new System.Drawing.Size(1005, 255);
            this.VRdataGridView.TabIndex = 4;
            this.VRdataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.VRdataGridView_CellContentClick);
            // 
            // vehiclesIDDataGridViewTextBoxColumn
            // 
            this.vehiclesIDDataGridViewTextBoxColumn.DataPropertyName = "VehiclesID";
            this.vehiclesIDDataGridViewTextBoxColumn.HeaderText = "VehiclesID";
            this.vehiclesIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.vehiclesIDDataGridViewTextBoxColumn.Name = "vehiclesIDDataGridViewTextBoxColumn";
            this.vehiclesIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.vehiclesIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // makeDataGridViewTextBoxColumn
            // 
            this.makeDataGridViewTextBoxColumn.DataPropertyName = "Make";
            this.makeDataGridViewTextBoxColumn.HeaderText = "Make";
            this.makeDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.makeDataGridViewTextBoxColumn.Name = "makeDataGridViewTextBoxColumn";
            this.makeDataGridViewTextBoxColumn.Width = 150;
            // 
            // modelDataGridViewTextBoxColumn
            // 
            this.modelDataGridViewTextBoxColumn.DataPropertyName = "Model";
            this.modelDataGridViewTextBoxColumn.HeaderText = "Model";
            this.modelDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.modelDataGridViewTextBoxColumn.Name = "modelDataGridViewTextBoxColumn";
            this.modelDataGridViewTextBoxColumn.Width = 150;
            // 
            // yearDataGridViewTextBoxColumn
            // 
            this.yearDataGridViewTextBoxColumn.DataPropertyName = "Year";
            this.yearDataGridViewTextBoxColumn.HeaderText = "Year";
            this.yearDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.yearDataGridViewTextBoxColumn.Name = "yearDataGridViewTextBoxColumn";
            this.yearDataGridViewTextBoxColumn.Width = 150;
            // 
            // statusDataGridViewTextBoxColumn
            // 
            this.statusDataGridViewTextBoxColumn.DataPropertyName = "Status";
            this.statusDataGridViewTextBoxColumn.HeaderText = "Status";
            this.statusDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.statusDataGridViewTextBoxColumn.Name = "statusDataGridViewTextBoxColumn";
            this.statusDataGridViewTextBoxColumn.Width = 150;
            // 
            // capacityDataGridViewTextBoxColumn
            // 
            this.capacityDataGridViewTextBoxColumn.DataPropertyName = "Capacity";
            this.capacityDataGridViewTextBoxColumn.HeaderText = "Capacity";
            this.capacityDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.capacityDataGridViewTextBoxColumn.Name = "capacityDataGridViewTextBoxColumn";
            this.capacityDataGridViewTextBoxColumn.Width = 150;
            // 
            // veichleTypeDataGridViewTextBoxColumn
            // 
            this.veichleTypeDataGridViewTextBoxColumn.DataPropertyName = "VeichleType";
            this.veichleTypeDataGridViewTextBoxColumn.HeaderText = "VeichleType";
            this.veichleTypeDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.veichleTypeDataGridViewTextBoxColumn.Name = "veichleTypeDataGridViewTextBoxColumn";
            this.veichleTypeDataGridViewTextBoxColumn.Width = 150;
            // 
            // vehiclesBindingSource
            // 
            this.vehiclesBindingSource.DataMember = "Vehicles";
            this.vehiclesBindingSource.DataSource = this.cargo_Management_SystemDataSet;
            // 
            // cargo_Management_SystemDataSet
            // 
            this.cargo_Management_SystemDataSet.DataSetName = "Cargo_Management_SystemDataSet";
            this.cargo_Management_SystemDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // VMalabel
            // 
            this.VMalabel.AutoSize = true;
            this.VMalabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VMalabel.ForeColor = System.Drawing.Color.Teal;
            this.VMalabel.Location = new System.Drawing.Point(106, 385);
            this.VMalabel.Name = "VMalabel";
            this.VMalabel.Size = new System.Drawing.Size(65, 25);
            this.VMalabel.TabIndex = 6;
            this.VMalabel.Text = "Make";
            // 
            // VYlabel
            // 
            this.VYlabel.AutoSize = true;
            this.VYlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VYlabel.ForeColor = System.Drawing.Color.Teal;
            this.VYlabel.Location = new System.Drawing.Point(604, 386);
            this.VYlabel.Name = "VYlabel";
            this.VYlabel.Size = new System.Drawing.Size(57, 25);
            this.VYlabel.TabIndex = 7;
            this.VYlabel.Text = "Year";
            // 
            // VClabel
            // 
            this.VClabel.AutoSize = true;
            this.VClabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VClabel.ForeColor = System.Drawing.Color.Teal;
            this.VClabel.Location = new System.Drawing.Point(346, 449);
            this.VClabel.Name = "VClabel";
            this.VClabel.Size = new System.Drawing.Size(97, 25);
            this.VClabel.TabIndex = 8;
            this.VClabel.Text = "Capacity";
            // 
            // VSlabel
            // 
            this.VSlabel.AutoSize = true;
            this.VSlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VSlabel.ForeColor = System.Drawing.Color.Teal;
            this.VSlabel.Location = new System.Drawing.Point(97, 451);
            this.VSlabel.Name = "VSlabel";
            this.VSlabel.Size = new System.Drawing.Size(74, 25);
            this.VSlabel.TabIndex = 9;
            this.VSlabel.Text = "Status";
            // 
            // VMolabel
            // 
            this.VMolabel.AutoSize = true;
            this.VMolabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VMolabel.ForeColor = System.Drawing.Color.Teal;
            this.VMolabel.Location = new System.Drawing.Point(355, 382);
            this.VMolabel.Name = "VMolabel";
            this.VMolabel.Size = new System.Drawing.Size(71, 25);
            this.VMolabel.TabIndex = 10;
            this.VMolabel.Text = "Model";
            // 
            // VTlabel
            // 
            this.VTlabel.AutoSize = true;
            this.VTlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VTlabel.ForeColor = System.Drawing.Color.Teal;
            this.VTlabel.Location = new System.Drawing.Point(600, 449);
            this.VTlabel.Name = "VTlabel";
            this.VTlabel.Size = new System.Drawing.Size(61, 25);
            this.VTlabel.TabIndex = 11;
            this.VTlabel.Text = "Type";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // VTtextBox
            // 
            this.VTtextBox.Location = new System.Drawing.Point(667, 448);
            this.VTtextBox.Name = "VTtextBox";
            this.VTtextBox.Size = new System.Drawing.Size(184, 26);
            this.VTtextBox.TabIndex = 14;
            // 
            // VYtextBox
            // 
            this.VYtextBox.Location = new System.Drawing.Point(667, 383);
            this.VYtextBox.Name = "VYtextBox";
            this.VYtextBox.Size = new System.Drawing.Size(100, 26);
            this.VYtextBox.TabIndex = 15;
            // 
            // VMotextBox
            // 
            this.VMotextBox.Location = new System.Drawing.Point(449, 381);
            this.VMotextBox.Name = "VMotextBox";
            this.VMotextBox.Size = new System.Drawing.Size(130, 26);
            this.VMotextBox.TabIndex = 16;
            // 
            // VMatextBox
            // 
            this.VMatextBox.Location = new System.Drawing.Point(176, 385);
            this.VMatextBox.Name = "VMatextBox";
            this.VMatextBox.Size = new System.Drawing.Size(132, 26);
            this.VMatextBox.TabIndex = 17;
            // 
            // VCtextBox
            // 
            this.VCtextBox.Location = new System.Drawing.Point(449, 448);
            this.VCtextBox.Name = "VCtextBox";
            this.VCtextBox.Size = new System.Drawing.Size(127, 26);
            this.VCtextBox.TabIndex = 19;
            // 
            // Vinsertbutton
            // 
            this.Vinsertbutton.BackColor = System.Drawing.Color.Teal;
            this.Vinsertbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Vinsertbutton.ForeColor = System.Drawing.Color.MintCream;
            this.Vinsertbutton.Location = new System.Drawing.Point(700, 533);
            this.Vinsertbutton.Name = "Vinsertbutton";
            this.Vinsertbutton.Size = new System.Drawing.Size(101, 41);
            this.Vinsertbutton.TabIndex = 20;
            this.Vinsertbutton.Text = "Add";
            this.Vinsertbutton.UseVisualStyleBackColor = false;
            this.Vinsertbutton.Click += new System.EventHandler(this.Vinsertbutton_Click);
            // 
            // VRExitbutton
            // 
            this.VRExitbutton.BackColor = System.Drawing.Color.Teal;
            this.VRExitbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VRExitbutton.ForeColor = System.Drawing.Color.MintCream;
            this.VRExitbutton.Location = new System.Drawing.Point(836, 533);
            this.VRExitbutton.Name = "VRExitbutton";
            this.VRExitbutton.Size = new System.Drawing.Size(101, 41);
            this.VRExitbutton.TabIndex = 21;
            this.VRExitbutton.Text = "Exit";
            this.VRExitbutton.UseVisualStyleBackColor = false;
            this.VRExitbutton.Click += new System.EventHandler(this.VRExitbutton_Click);
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.freeToolStripMenuItem,
            this.activeToolStripMenuItem,
            this.maintenanceToolStripMenuItem,
            this.retiredToolStripMenuItem});
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(185, 132);
            // 
            // freeToolStripMenuItem
            // 
            this.freeToolStripMenuItem.Name = "freeToolStripMenuItem";
            this.freeToolStripMenuItem.Size = new System.Drawing.Size(184, 32);
            this.freeToolStripMenuItem.Text = "Free";
            // 
            // activeToolStripMenuItem
            // 
            this.activeToolStripMenuItem.Name = "activeToolStripMenuItem";
            this.activeToolStripMenuItem.Size = new System.Drawing.Size(184, 32);
            this.activeToolStripMenuItem.Text = "Active";
            // 
            // maintenanceToolStripMenuItem
            // 
            this.maintenanceToolStripMenuItem.Name = "maintenanceToolStripMenuItem";
            this.maintenanceToolStripMenuItem.Size = new System.Drawing.Size(184, 32);
            this.maintenanceToolStripMenuItem.Text = "Maintenance";
            // 
            // retiredToolStripMenuItem
            // 
            this.retiredToolStripMenuItem.Name = "retiredToolStripMenuItem";
            this.retiredToolStripMenuItem.Size = new System.Drawing.Size(184, 32);
            this.retiredToolStripMenuItem.Text = "Retired";
            // 
            // VRstatuscomboobx
            // 
            this.VRstatuscomboobx.FormattingEnabled = true;
            this.VRstatuscomboobx.Items.AddRange(new object[] {
            "Free",
            "Active",
            "Maintenance",
            "Retired"});
            this.VRstatuscomboobx.Location = new System.Drawing.Point(176, 446);
            this.VRstatuscomboobx.Name = "VRstatuscomboobx";
            this.VRstatuscomboobx.Size = new System.Drawing.Size(132, 28);
            this.VRstatuscomboobx.TabIndex = 23;
            // 
            // vehiclesTableAdapter
            // 
            this.vehiclesTableAdapter.ClearBeforeFill = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Location = new System.Drawing.Point(0, 344);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1005, 10);
            this.panel1.TabIndex = 43;
            // 
            // VeichleRegisterationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MintCream;
            this.ClientSize = new System.Drawing.Size(1005, 603);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.VRstatuscomboobx);
            this.Controls.Add(this.VRExitbutton);
            this.Controls.Add(this.Vinsertbutton);
            this.Controls.Add(this.VCtextBox);
            this.Controls.Add(this.VMatextBox);
            this.Controls.Add(this.VMotextBox);
            this.Controls.Add(this.VYtextBox);
            this.Controls.Add(this.VTtextBox);
            this.Controls.Add(this.VTlabel);
            this.Controls.Add(this.VMolabel);
            this.Controls.Add(this.VSlabel);
            this.Controls.Add(this.VClabel);
            this.Controls.Add(this.VYlabel);
            this.Controls.Add(this.VMalabel);
            this.Controls.Add(this.VRdataGridView);
            this.Controls.Add(this.veichleregformpanel);
            this.Name = "VeichleRegisterationForm";
            this.Text = "VeichleRegisterationForm";
            this.Load += new System.EventHandler(this.VeichleRegisterationForm_Load);
            this.veichleregformpanel.ResumeLayout(false);
            this.veichleregformpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.VRdataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vehiclesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cargo_Management_SystemDataSet)).EndInit();
            this.contextMenuStrip2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel veichleregformpanel;
        private System.Windows.Forms.Label namelabel;
        private System.Windows.Forms.Label Form1label;
        private System.Windows.Forms.DataGridView VRdataGridView;
        private System.Windows.Forms.Label VMalabel;
        private System.Windows.Forms.Label VYlabel;
        private System.Windows.Forms.Label VClabel;
        private System.Windows.Forms.Label VSlabel;
        private System.Windows.Forms.Label VMolabel;
        private System.Windows.Forms.Label VTlabel;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.TextBox VTtextBox;
        private System.Windows.Forms.TextBox VYtextBox;
        private System.Windows.Forms.TextBox VMotextBox;
        private System.Windows.Forms.TextBox VMatextBox;
        private System.Windows.Forms.TextBox VCtextBox;
        private System.Windows.Forms.Button Vinsertbutton;
        private System.Windows.Forms.Button VRExitbutton;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem freeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem activeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem maintenanceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem retiredToolStripMenuItem;
        private System.Windows.Forms.ComboBox VRstatuscomboobx;
        private Cargo_Management_SystemDataSet cargo_Management_SystemDataSet;
        private System.Windows.Forms.BindingSource vehiclesBindingSource;
        private Cargo_Management_SystemDataSetTableAdapters.VehiclesTableAdapter vehiclesTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn vehiclesIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn makeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn modelDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn yearDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn statusDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn capacityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn veichleTypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.Panel panel1;
    }
}