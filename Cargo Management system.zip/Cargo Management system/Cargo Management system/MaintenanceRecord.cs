﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cargo_Management_system
{
    public partial class MaintenanceRecordForm : Form
    {
        public MaintenanceRecordForm()
        {
            InitializeComponent();
        }

        private void MaintenanceRecordForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'cargo_Management_SystemDataSet.Vehicles' table. You can move, or remove it, as needed.
            this.vehiclesTableAdapter.Fill(this.cargo_Management_SystemDataSet.Vehicles);
            // TODO: This line of code loads data into the 'cargo_Management_SystemDataSet.MaintenanceRecords' table. You can move, or remove it, as needed.
            this.maintenanceRecordsTableAdapter.Fill(this.cargo_Management_SystemDataSet.MaintenanceRecords);
            // TODO: This line of code loads data into the 'cargo_Management_SystemDataSet.FuelLogs' table. You can move, or remove it, as needed.
            this.fuelLogsTableAdapter.Fill(this.cargo_Management_SystemDataSet.FuelLogs);

        }

        private void ManageMaintenanceRecordbutton_Click(object sender, EventArgs e)
        {
            ManageMaintananceRecordForm Form = new ManageMaintananceRecordForm();
            Form.Show();
        }

        private void ExitMaintananceRecordbutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void AddMaintananceRecordbutton_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-04KFGU9\\SQLSERVER2022;Initial Catalog=\"Cargo Management System\";Integrated Security=True;Encrypt=False";
            string insertQuery = @"INSERT INTO MaintenanceRecords (VehicleID, Date, Description, Cost)
                                 VALUES (@VehicleID, @Date, @Description, @Cost)";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(insertQuery, con))
                {
                    cmd.Parameters.AddWithValue("@VehicleID", int.Parse(VeichleIDcomboBox.Text)); 
                    cmd.Parameters.AddWithValue("@Date", DateTime.Parse(MaintenancedateTimePicker.Text));
                    SqlParameter descriptionParam = new SqlParameter("@Description", SqlDbType.Text);
                    descriptionParam.Value = DescriptiontextBox.Text;
                    cmd.Parameters.Add(descriptionParam);

                    cmd.Parameters.AddWithValue("@Cost", decimal.Parse(CosttextBox.Text));

                    try
                    {
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();

                        // Show a success message
                        MessageBox.Show("Maintenance record data inserted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show($"Error inserting maintenance record data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                }
            }
            this.Close();



        }
    }
}
