﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cargo_Management_system
{
    public partial class ManageCargoForm : Form
    {
        public ManageCargoForm()
        {
            InitializeComponent();
        }

        private void ManageCargoForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'cargo_Management_SystemDataSet.Warehouse' table. You can move, or remove it, as needed.
            this.warehouseTableAdapter.Fill(this.cargo_Management_SystemDataSet.Warehouse);
            // TODO: This line of code loads data into the 'cargo_Management_SystemDataSet.Clients' table. You can move, or remove it, as needed.
            this.clientsTableAdapter.Fill(this.cargo_Management_SystemDataSet.Clients);
            // TODO: This line of code loads data into the 'cargo_Management_SystemDataSet.Cargo' table. You can move, or remove it, as needed.
            this.cargoTableAdapter.Fill(this.cargo_Management_SystemDataSet.Cargo);

        }

        private void ClientsDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                CargoIDcomboBox.Text = CargoDataGridView.Rows[e.RowIndex].Cells[0].Value.ToString();
                WarehouseIDcomboBox.Text = CargoDataGridView.Rows[e.RowIndex].Cells[1].Value.ToString();
                ClientIDcomboBox.Text = CargoDataGridView.Rows[e.RowIndex].Cells[2].Value.ToString();
                DescriptiontextBox.Text = CargoDataGridView.Rows[e.RowIndex].Cells[3].Value.ToString();
                WeighttextBox.Text = CargoDataGridView.Rows[e.RowIndex].Cells[4].Value.ToString();
                DimensionscomboBox.Text = CargoDataGridView.Rows[e.RowIndex].Cells[5].Value.ToString();
                SpecialRequirementstextBox.Text = CargoDataGridView.Rows[e.RowIndex].Cells[6].Value.ToString();
                StatuscomboBox.Text = CargoDataGridView.Rows[e.RowIndex].Cells[7].Value.ToString();
            }

        }

        private void Exittbutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Deletebutton_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-04KFGU9\\SQLSERVER2022;Initial Catalog=\"Cargo Management System\";Integrated Security=True;Encrypt=False";
            string deleteQuery = @"DELETE FROM Cargo WHERE CargoID = @CargoID";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(deleteQuery, con))
                {
              
                    cmd.Parameters.AddWithValue("@CargoID", int.Parse(CargoIDcomboBox.Text)); 

                    try
                    {
                        con.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        con.Close();

                        // Show a success message if rowsAffected is greater than 0
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Cargo record deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("No cargo record found with the specified CargoID.", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    catch (Exception ex)
                    {
                        // Show an error message
                        MessageBox.Show($"Error deleting cargo record: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }

            this.Close();
        }

        private void Updatebutton_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-04KFGU9\\SQLSERVER2022;Initial Catalog=\"Cargo Management System\";Integrated Security=True;Encrypt=False";
            string updateQuery = @"UPDATE Cargo SET WarehouseID = @WarehouseID, ClientID = @ClientID ,Description = @Description, Weight = @Weight,
                                Dimensions = @Dimensions, SpecialRequirements = @SpecialRequirements, Status = @Status WHERE CargoID = @CargoID";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(updateQuery, con))
                {
                  
                    cmd.Parameters.AddWithValue("@WarehouseID", int.Parse(WarehouseIDcomboBox.Text)); 
                    cmd.Parameters.AddWithValue("@ClientID", int.Parse(ClientIDcomboBox.Text)); 
                    cmd.Parameters.AddWithValue("@Description", DescriptiontextBox.Text); 
                    cmd.Parameters.AddWithValue("@Weight", decimal.Parse(WeighttextBox.Text)); 
                    cmd.Parameters.AddWithValue("@Dimensions", DimensionscomboBox.Text); 
                    cmd.Parameters.AddWithValue("@SpecialRequirements", SpecialRequirementstextBox.Text); 
                    cmd.Parameters.AddWithValue("@Status", StatuscomboBox.SelectedItem.ToString()); 
                    cmd.Parameters.AddWithValue("@CargoID", int.Parse(CargoIDcomboBox.Text)); 

                    try
                    {
                        con.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        con.Close();

                        // Show a success message if rowsAffected is greater than 0
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Cargo record updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("No cargo record found with the specified CargoID to update.", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    catch (Exception ex)
                    {
                        // Show an error message
                        MessageBox.Show($"Error updating cargo record: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }

            this.Close();
        }
    }
}
