﻿namespace Cargo_Management_system
{
    partial class ScheduledTripForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.CargoIDcomboBox = new System.Windows.Forms.ComboBox();
            this.StartdateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.locnamelabel = new System.Windows.Forms.Label();
            this.Exitbutton = new System.Windows.Forms.Button();
            this.AddScheduledTripbutton = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.MVdataGridView = new System.Windows.Forms.DataGridView();
            this.tripIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cargoIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vehicleIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.driverIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.startDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.endDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.originDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.destinationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tripsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cargo_Management_SystemDataSet = new Cargo_Management_system.Cargo_Management_SystemDataSet();
            this.warehouseformpanel = new System.Windows.Forms.Panel();
            this.MaintenanceRecordFormlabel = new System.Windows.Forms.Label();
            this.namelabel = new System.Windows.Forms.Label();
            this.tripsTableAdapter = new Cargo_Management_system.Cargo_Management_SystemDataSetTableAdapters.TripsTableAdapter();
            this.VehicleIDcomboBox = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.vehiclesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.vehiclesTableAdapter = new Cargo_Management_system.Cargo_Management_SystemDataSetTableAdapters.VehiclesTableAdapter();
            this.cargoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cargoTableAdapter = new Cargo_Management_system.Cargo_Management_SystemDataSetTableAdapters.CargoTableAdapter();
            this.EnddateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.DriverIDcomboBox = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.driversBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.driversTableAdapter = new Cargo_Management_system.Cargo_Management_SystemDataSetTableAdapters.DriversTableAdapter();
            this.StatuscomboBox = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.DestinationcomboBox = new System.Windows.Forms.ComboBox();
            this.OrigincomboBox = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.MVdataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tripsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cargo_Management_SystemDataSet)).BeginInit();
            this.warehouseformpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.vehiclesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cargoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.driversBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // CargoIDcomboBox
            // 
            this.CargoIDcomboBox.DataSource = this.cargoBindingSource;
            this.CargoIDcomboBox.DisplayMember = "CargoID";
            this.CargoIDcomboBox.FormattingEnabled = true;
            this.CargoIDcomboBox.Location = new System.Drawing.Point(422, 412);
            this.CargoIDcomboBox.Name = "CargoIDcomboBox";
            this.CargoIDcomboBox.Size = new System.Drawing.Size(121, 28);
            this.CargoIDcomboBox.TabIndex = 88;
            this.CargoIDcomboBox.ValueMember = "CargoID";
            // 
            // StartdateTimePicker
            // 
            this.StartdateTimePicker.Location = new System.Drawing.Point(145, 482);
            this.StartdateTimePicker.Name = "StartdateTimePicker";
            this.StartdateTimePicker.Size = new System.Drawing.Size(200, 26);
            this.StartdateTimePicker.TabIndex = 85;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Teal;
            this.label5.Location = new System.Drawing.Point(319, 414);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 25);
            this.label5.TabIndex = 84;
            this.label5.Text = "CargoID";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Teal;
            this.label4.Location = new System.Drawing.Point(13, 483);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(103, 25);
            this.label4.TabIndex = 83;
            this.label4.Text = "StartDate";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Teal;
            this.label1.Location = new System.Drawing.Point(274, 564);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 25);
            this.label1.TabIndex = 82;
            this.label1.Text = "Destination";
            // 
            // locnamelabel
            // 
            this.locnamelabel.AutoSize = true;
            this.locnamelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.locnamelabel.ForeColor = System.Drawing.Color.Teal;
            this.locnamelabel.Location = new System.Drawing.Point(19, 559);
            this.locnamelabel.Name = "locnamelabel";
            this.locnamelabel.Size = new System.Drawing.Size(70, 25);
            this.locnamelabel.TabIndex = 81;
            this.locnamelabel.Text = "Origin";
            // 
            // Exitbutton
            // 
            this.Exitbutton.BackColor = System.Drawing.Color.Teal;
            this.Exitbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Exitbutton.ForeColor = System.Drawing.Color.MintCream;
            this.Exitbutton.Location = new System.Drawing.Point(859, 556);
            this.Exitbutton.Name = "Exitbutton";
            this.Exitbutton.Size = new System.Drawing.Size(111, 41);
            this.Exitbutton.TabIndex = 80;
            this.Exitbutton.Text = "Exit";
            this.Exitbutton.UseVisualStyleBackColor = false;
            this.Exitbutton.Click += new System.EventHandler(this.Exitbutton_Click);
            // 
            // AddScheduledTripbutton
            // 
            this.AddScheduledTripbutton.BackColor = System.Drawing.Color.Teal;
            this.AddScheduledTripbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddScheduledTripbutton.ForeColor = System.Drawing.Color.MintCream;
            this.AddScheduledTripbutton.Location = new System.Drawing.Point(714, 556);
            this.AddScheduledTripbutton.Name = "AddScheduledTripbutton";
            this.AddScheduledTripbutton.Size = new System.Drawing.Size(111, 41);
            this.AddScheduledTripbutton.TabIndex = 79;
            this.AddScheduledTripbutton.Text = "Add";
            this.AddScheduledTripbutton.UseVisualStyleBackColor = false;
            this.AddScheduledTripbutton.Click += new System.EventHandler(this.AddScheduledTripbutton_Click_1);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Location = new System.Drawing.Point(0, 373);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1005, 10);
            this.panel1.TabIndex = 78;
            // 
            // MVdataGridView
            // 
            this.MVdataGridView.AutoGenerateColumns = false;
            this.MVdataGridView.BackgroundColor = System.Drawing.Color.MintCream;
            this.MVdataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.MVdataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.tripIDDataGridViewTextBoxColumn,
            this.cargoIDDataGridViewTextBoxColumn,
            this.vehicleIDDataGridViewTextBoxColumn,
            this.driverIDDataGridViewTextBoxColumn,
            this.startDateDataGridViewTextBoxColumn,
            this.endDateDataGridViewTextBoxColumn,
            this.originDataGridViewTextBoxColumn,
            this.destinationDataGridViewTextBoxColumn,
            this.statusDataGridViewTextBoxColumn});
            this.MVdataGridView.DataSource = this.tripsBindingSource;
            this.MVdataGridView.Dock = System.Windows.Forms.DockStyle.Top;
            this.MVdataGridView.GridColor = System.Drawing.Color.Teal;
            this.MVdataGridView.Location = new System.Drawing.Point(0, 101);
            this.MVdataGridView.Name = "MVdataGridView";
            this.MVdataGridView.RowHeadersWidth = 62;
            this.MVdataGridView.RowTemplate.Height = 28;
            this.MVdataGridView.Size = new System.Drawing.Size(1005, 276);
            this.MVdataGridView.TabIndex = 77;
            this.MVdataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.MVdataGridView_CellContentClick);
            // 
            // tripIDDataGridViewTextBoxColumn
            // 
            this.tripIDDataGridViewTextBoxColumn.DataPropertyName = "TripID";
            this.tripIDDataGridViewTextBoxColumn.HeaderText = "TripID";
            this.tripIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.tripIDDataGridViewTextBoxColumn.Name = "tripIDDataGridViewTextBoxColumn";
            this.tripIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.tripIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // cargoIDDataGridViewTextBoxColumn
            // 
            this.cargoIDDataGridViewTextBoxColumn.DataPropertyName = "CargoID";
            this.cargoIDDataGridViewTextBoxColumn.HeaderText = "CargoID";
            this.cargoIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.cargoIDDataGridViewTextBoxColumn.Name = "cargoIDDataGridViewTextBoxColumn";
            this.cargoIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // vehicleIDDataGridViewTextBoxColumn
            // 
            this.vehicleIDDataGridViewTextBoxColumn.DataPropertyName = "VehicleID";
            this.vehicleIDDataGridViewTextBoxColumn.HeaderText = "VehicleID";
            this.vehicleIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.vehicleIDDataGridViewTextBoxColumn.Name = "vehicleIDDataGridViewTextBoxColumn";
            this.vehicleIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // driverIDDataGridViewTextBoxColumn
            // 
            this.driverIDDataGridViewTextBoxColumn.DataPropertyName = "DriverID";
            this.driverIDDataGridViewTextBoxColumn.HeaderText = "DriverID";
            this.driverIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.driverIDDataGridViewTextBoxColumn.Name = "driverIDDataGridViewTextBoxColumn";
            this.driverIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // startDateDataGridViewTextBoxColumn
            // 
            this.startDateDataGridViewTextBoxColumn.DataPropertyName = "StartDate";
            this.startDateDataGridViewTextBoxColumn.HeaderText = "StartDate";
            this.startDateDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.startDateDataGridViewTextBoxColumn.Name = "startDateDataGridViewTextBoxColumn";
            this.startDateDataGridViewTextBoxColumn.Width = 150;
            // 
            // endDateDataGridViewTextBoxColumn
            // 
            this.endDateDataGridViewTextBoxColumn.DataPropertyName = "EndDate";
            this.endDateDataGridViewTextBoxColumn.HeaderText = "EndDate";
            this.endDateDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.endDateDataGridViewTextBoxColumn.Name = "endDateDataGridViewTextBoxColumn";
            this.endDateDataGridViewTextBoxColumn.Width = 150;
            // 
            // originDataGridViewTextBoxColumn
            // 
            this.originDataGridViewTextBoxColumn.DataPropertyName = "Origin";
            this.originDataGridViewTextBoxColumn.HeaderText = "Origin";
            this.originDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.originDataGridViewTextBoxColumn.Name = "originDataGridViewTextBoxColumn";
            this.originDataGridViewTextBoxColumn.Width = 150;
            // 
            // destinationDataGridViewTextBoxColumn
            // 
            this.destinationDataGridViewTextBoxColumn.DataPropertyName = "Destination";
            this.destinationDataGridViewTextBoxColumn.HeaderText = "Destination";
            this.destinationDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.destinationDataGridViewTextBoxColumn.Name = "destinationDataGridViewTextBoxColumn";
            this.destinationDataGridViewTextBoxColumn.Width = 150;
            // 
            // statusDataGridViewTextBoxColumn
            // 
            this.statusDataGridViewTextBoxColumn.DataPropertyName = "Status";
            this.statusDataGridViewTextBoxColumn.HeaderText = "Status";
            this.statusDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.statusDataGridViewTextBoxColumn.Name = "statusDataGridViewTextBoxColumn";
            this.statusDataGridViewTextBoxColumn.Width = 150;
            // 
            // tripsBindingSource
            // 
            this.tripsBindingSource.DataMember = "Trips";
            this.tripsBindingSource.DataSource = this.cargo_Management_SystemDataSet;
            // 
            // cargo_Management_SystemDataSet
            // 
            this.cargo_Management_SystemDataSet.DataSetName = "Cargo_Management_SystemDataSet";
            this.cargo_Management_SystemDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // warehouseformpanel
            // 
            this.warehouseformpanel.BackColor = System.Drawing.Color.Teal;
            this.warehouseformpanel.Controls.Add(this.MaintenanceRecordFormlabel);
            this.warehouseformpanel.Controls.Add(this.namelabel);
            this.warehouseformpanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.warehouseformpanel.Location = new System.Drawing.Point(0, 0);
            this.warehouseformpanel.Name = "warehouseformpanel";
            this.warehouseformpanel.Size = new System.Drawing.Size(1005, 101);
            this.warehouseformpanel.TabIndex = 76;
            // 
            // MaintenanceRecordFormlabel
            // 
            this.MaintenanceRecordFormlabel.AutoSize = true;
            this.MaintenanceRecordFormlabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaintenanceRecordFormlabel.ForeColor = System.Drawing.Color.MintCream;
            this.MaintenanceRecordFormlabel.Location = new System.Drawing.Point(352, 33);
            this.MaintenanceRecordFormlabel.Name = "MaintenanceRecordFormlabel";
            this.MaintenanceRecordFormlabel.Size = new System.Drawing.Size(259, 42);
            this.MaintenanceRecordFormlabel.TabIndex = 1;
            this.MaintenanceRecordFormlabel.Text = "Scheduled Trip";
            // 
            // namelabel
            // 
            this.namelabel.AutoSize = true;
            this.namelabel.ForeColor = System.Drawing.Color.MintCream;
            this.namelabel.Location = new System.Drawing.Point(291, 33);
            this.namelabel.Name = "namelabel";
            this.namelabel.Size = new System.Drawing.Size(0, 20);
            this.namelabel.TabIndex = 0;
            // 
            // tripsTableAdapter
            // 
            this.tripsTableAdapter.ClearBeforeFill = true;
            // 
            // VehicleIDcomboBox
            // 
            this.VehicleIDcomboBox.DataSource = this.vehiclesBindingSource;
            this.VehicleIDcomboBox.DisplayMember = "VehiclesID";
            this.VehicleIDcomboBox.FormattingEnabled = true;
            this.VehicleIDcomboBox.Location = new System.Drawing.Point(145, 415);
            this.VehicleIDcomboBox.Name = "VehicleIDcomboBox";
            this.VehicleIDcomboBox.Size = new System.Drawing.Size(121, 28);
            this.VehicleIDcomboBox.TabIndex = 91;
            this.VehicleIDcomboBox.ValueMember = "VehiclesID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Teal;
            this.label2.Location = new System.Drawing.Point(21, 414);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 25);
            this.label2.TabIndex = 90;
            this.label2.Text = "VehicleID";
            // 
            // vehiclesBindingSource
            // 
            this.vehiclesBindingSource.DataMember = "Vehicles";
            this.vehiclesBindingSource.DataSource = this.cargo_Management_SystemDataSet;
            // 
            // vehiclesTableAdapter
            // 
            this.vehiclesTableAdapter.ClearBeforeFill = true;
            // 
            // cargoBindingSource
            // 
            this.cargoBindingSource.DataMember = "Cargo";
            this.cargoBindingSource.DataSource = this.cargo_Management_SystemDataSet;
            // 
            // cargoTableAdapter
            // 
            this.cargoTableAdapter.ClearBeforeFill = true;
            // 
            // EnddateTimePicker
            // 
            this.EnddateTimePicker.Location = new System.Drawing.Point(498, 481);
            this.EnddateTimePicker.Name = "EnddateTimePicker";
            this.EnddateTimePicker.Size = new System.Drawing.Size(200, 26);
            this.EnddateTimePicker.TabIndex = 93;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Teal;
            this.label3.Location = new System.Drawing.Point(375, 482);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 25);
            this.label3.TabIndex = 92;
            this.label3.Text = "EndDate";
            // 
            // DriverIDcomboBox
            // 
            this.DriverIDcomboBox.DataSource = this.driversBindingSource;
            this.DriverIDcomboBox.DisplayMember = "DriverID";
            this.DriverIDcomboBox.FormattingEnabled = true;
            this.DriverIDcomboBox.Location = new System.Drawing.Point(720, 408);
            this.DriverIDcomboBox.Name = "DriverIDcomboBox";
            this.DriverIDcomboBox.Size = new System.Drawing.Size(121, 28);
            this.DriverIDcomboBox.TabIndex = 95;
            this.DriverIDcomboBox.ValueMember = "DriverID";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Teal;
            this.label6.Location = new System.Drawing.Point(608, 411);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 25);
            this.label6.TabIndex = 94;
            this.label6.Text = "DriverID";
            // 
            // driversBindingSource
            // 
            this.driversBindingSource.DataMember = "Drivers";
            this.driversBindingSource.DataSource = this.cargo_Management_SystemDataSet;
            // 
            // driversTableAdapter
            // 
            this.driversTableAdapter.ClearBeforeFill = true;
            // 
            // StatuscomboBox
            // 
            this.StatuscomboBox.FormattingEnabled = true;
            this.StatuscomboBox.Items.AddRange(new object[] {
            "Scheduled",
            "In progress",
            "Completed",
            "Delayed"});
            this.StatuscomboBox.Location = new System.Drawing.Point(859, 478);
            this.StatuscomboBox.Name = "StatuscomboBox";
            this.StatuscomboBox.Size = new System.Drawing.Size(121, 28);
            this.StatuscomboBox.TabIndex = 97;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Teal;
            this.label7.Location = new System.Drawing.Point(751, 481);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(74, 25);
            this.label7.TabIndex = 96;
            this.label7.Text = "Status";
            // 
            // DestinationcomboBox
            // 
            this.DestinationcomboBox.FormattingEnabled = true;
            this.DestinationcomboBox.Items.AddRange(new object[] {
            "Karachi",
            "Lahore",
            "Faisalabad",
            "Rawalpindi",
            "Gujranwala",
            "Peshawar",
            "Multan",
            "Hyderabad",
            "Islamabad",
            "Quetta",
            "Bahawalpur",
            "Sargodha",
            "Sialkot",
            "Sukkur",
            "Larkana",
            "Rahim Yar Khan",
            "Sheikhupura",
            "Jhang",
            "Dera Ghazi Khan",
            "Gujrat"});
            this.DestinationcomboBox.Location = new System.Drawing.Point(422, 556);
            this.DestinationcomboBox.Name = "DestinationcomboBox";
            this.DestinationcomboBox.Size = new System.Drawing.Size(121, 28);
            this.DestinationcomboBox.TabIndex = 98;
            // 
            // OrigincomboBox
            // 
            this.OrigincomboBox.FormattingEnabled = true;
            this.OrigincomboBox.Items.AddRange(new object[] {
            "Karachi",
            "Lahore",
            "Faisalabad",
            "Rawalpindi",
            "Gujranwala",
            "Peshawar",
            "Multan",
            "Hyderabad",
            "Islamabad",
            "Quetta",
            "Bahawalpur",
            "Sargodha",
            "Sialkot",
            "Sukkur",
            "Larkana",
            "Rahim Yar Khan",
            "Sheikhupura",
            "Jhang",
            "Dera Ghazi Khan",
            "Gujrat"});
            this.OrigincomboBox.Location = new System.Drawing.Point(95, 556);
            this.OrigincomboBox.Name = "OrigincomboBox";
            this.OrigincomboBox.Size = new System.Drawing.Size(121, 28);
            this.OrigincomboBox.TabIndex = 99;
            // 
            // ScheduledTripForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MintCream;
            this.ClientSize = new System.Drawing.Size(1005, 603);
            this.Controls.Add(this.OrigincomboBox);
            this.Controls.Add(this.DestinationcomboBox);
            this.Controls.Add(this.StatuscomboBox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.DriverIDcomboBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.EnddateTimePicker);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.VehicleIDcomboBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.CargoIDcomboBox);
            this.Controls.Add(this.StartdateTimePicker);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.locnamelabel);
            this.Controls.Add(this.Exitbutton);
            this.Controls.Add(this.AddScheduledTripbutton);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.MVdataGridView);
            this.Controls.Add(this.warehouseformpanel);
            this.Name = "ScheduledTripForm";
            this.Text = "ScheduledTripForm";
            this.Load += new System.EventHandler(this.ScheduledTripForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.MVdataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tripsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cargo_Management_SystemDataSet)).EndInit();
            this.warehouseformpanel.ResumeLayout(false);
            this.warehouseformpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.vehiclesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cargoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.driversBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ComboBox CargoIDcomboBox;
        private System.Windows.Forms.DateTimePicker StartdateTimePicker;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label locnamelabel;
        private System.Windows.Forms.Button Exitbutton;
        private System.Windows.Forms.Button AddScheduledTripbutton;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView MVdataGridView;
        private System.Windows.Forms.Panel warehouseformpanel;
        private System.Windows.Forms.Label MaintenanceRecordFormlabel;
        private System.Windows.Forms.Label namelabel;
        private Cargo_Management_SystemDataSet cargo_Management_SystemDataSet;
        private System.Windows.Forms.BindingSource tripsBindingSource;
        private Cargo_Management_SystemDataSetTableAdapters.TripsTableAdapter tripsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn tripIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cargoIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn vehicleIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn driverIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn startDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn endDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn originDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn destinationDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn statusDataGridViewTextBoxColumn;
        private System.Windows.Forms.ComboBox VehicleIDcomboBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.BindingSource vehiclesBindingSource;
        private Cargo_Management_SystemDataSetTableAdapters.VehiclesTableAdapter vehiclesTableAdapter;
        private System.Windows.Forms.BindingSource cargoBindingSource;
        private Cargo_Management_SystemDataSetTableAdapters.CargoTableAdapter cargoTableAdapter;
        private System.Windows.Forms.DateTimePicker EnddateTimePicker;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox DriverIDcomboBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.BindingSource driversBindingSource;
        private Cargo_Management_SystemDataSetTableAdapters.DriversTableAdapter driversTableAdapter;
        private System.Windows.Forms.ComboBox StatuscomboBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox DestinationcomboBox;
        private System.Windows.Forms.ComboBox OrigincomboBox;
    }
}