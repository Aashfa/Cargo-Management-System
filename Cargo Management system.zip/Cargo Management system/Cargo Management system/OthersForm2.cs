﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cargo_Management_system
{
    public partial class OthersForm2 : Form
    {
        public OthersForm2()
        {
            InitializeComponent();
        }

        private void Exitbutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void RegisterClientbutton_Click(object sender, EventArgs e)
        {
            RegisterClientForm Form = new RegisterClientForm();
            Form.Show();
        }

        private void ManageClientbutton_Click(object sender, EventArgs e)
        {
            ClientForm Form = new ClientForm();
            Form.Show();

        }

        private void ScheduledTripbutton_Click(object sender, EventArgs e)
        {
            ScheduledTripForm Form = new ScheduledTripForm();
            Form.Show();

        }

        private void ManageTripbutton_Click(object sender, EventArgs e)
        {
            ManageTripForm Form = new ManageTripForm();
            Form.Show();

        }
    }
}
