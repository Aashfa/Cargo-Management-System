﻿namespace Cargo_Management_system
{
    partial class DriverRegisterationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.warehouseformpanel = new System.Windows.Forms.Panel();
            this.warehouseFormlabel = new System.Windows.Forms.Label();
            this.namelabel = new System.Windows.Forms.Label();
            this.MVdataGridView = new System.Windows.Forms.DataGridView();
            this.driverIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.licenseNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.licenseExpiryDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.certificationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.driversBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cargo_Management_SystemDataSet = new Cargo_Management_system.Cargo_Management_SystemDataSet();
            this.VRExitbutton = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.driversTableAdapter = new Cargo_Management_system.Cargo_Management_SystemDataSetTableAdapters.DriversTableAdapter();
            this.AddDriverbutton = new System.Windows.Forms.Button();
            this.DriverLiscencedateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.DriverFirstNametextBox = new System.Windows.Forms.TextBox();
            this.DriverLastNametextBox = new System.Windows.Forms.TextBox();
            this.DriverLiscenceNotextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.DriverStatuscomboobx = new System.Windows.Forms.ComboBox();
            this.DriverCertificationtextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.warehouseformpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MVdataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.driversBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cargo_Management_SystemDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // warehouseformpanel
            // 
            this.warehouseformpanel.BackColor = System.Drawing.Color.Teal;
            this.warehouseformpanel.Controls.Add(this.warehouseFormlabel);
            this.warehouseformpanel.Controls.Add(this.namelabel);
            this.warehouseformpanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.warehouseformpanel.Location = new System.Drawing.Point(0, 0);
            this.warehouseformpanel.Name = "warehouseformpanel";
            this.warehouseformpanel.Size = new System.Drawing.Size(1005, 101);
            this.warehouseformpanel.TabIndex = 7;
            // 
            // warehouseFormlabel
            // 
            this.warehouseFormlabel.AutoSize = true;
            this.warehouseFormlabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.warehouseFormlabel.ForeColor = System.Drawing.Color.MintCream;
            this.warehouseFormlabel.Location = new System.Drawing.Point(384, 33);
            this.warehouseFormlabel.Name = "warehouseFormlabel";
            this.warehouseFormlabel.Size = new System.Drawing.Size(342, 42);
            this.warehouseFormlabel.TabIndex = 1;
            this.warehouseFormlabel.Text = "Driver Registeration";
            // 
            // namelabel
            // 
            this.namelabel.AutoSize = true;
            this.namelabel.ForeColor = System.Drawing.Color.MintCream;
            this.namelabel.Location = new System.Drawing.Point(291, 33);
            this.namelabel.Name = "namelabel";
            this.namelabel.Size = new System.Drawing.Size(0, 20);
            this.namelabel.TabIndex = 0;
            // 
            // MVdataGridView
            // 
            this.MVdataGridView.AutoGenerateColumns = false;
            this.MVdataGridView.BackgroundColor = System.Drawing.Color.MintCream;
            this.MVdataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.MVdataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.driverIDDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.licenseNumberDataGridViewTextBoxColumn,
            this.licenseExpiryDateDataGridViewTextBoxColumn,
            this.statusDataGridViewTextBoxColumn,
            this.certificationDataGridViewTextBoxColumn});
            this.MVdataGridView.DataSource = this.driversBindingSource;
            this.MVdataGridView.Dock = System.Windows.Forms.DockStyle.Top;
            this.MVdataGridView.GridColor = System.Drawing.Color.Teal;
            this.MVdataGridView.Location = new System.Drawing.Point(0, 101);
            this.MVdataGridView.Name = "MVdataGridView";
            this.MVdataGridView.RowHeadersWidth = 62;
            this.MVdataGridView.RowTemplate.Height = 28;
            this.MVdataGridView.Size = new System.Drawing.Size(1005, 276);
            this.MVdataGridView.TabIndex = 36;
            // 
            // driverIDDataGridViewTextBoxColumn
            // 
            this.driverIDDataGridViewTextBoxColumn.DataPropertyName = "DriverID";
            this.driverIDDataGridViewTextBoxColumn.HeaderText = "DriverID";
            this.driverIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.driverIDDataGridViewTextBoxColumn.Name = "driverIDDataGridViewTextBoxColumn";
            this.driverIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.driverIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            this.firstNameDataGridViewTextBoxColumn.Width = 150;
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            this.lastNameDataGridViewTextBoxColumn.Width = 150;
            // 
            // licenseNumberDataGridViewTextBoxColumn
            // 
            this.licenseNumberDataGridViewTextBoxColumn.DataPropertyName = "LicenseNumber";
            this.licenseNumberDataGridViewTextBoxColumn.HeaderText = "LicenseNumber";
            this.licenseNumberDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.licenseNumberDataGridViewTextBoxColumn.Name = "licenseNumberDataGridViewTextBoxColumn";
            this.licenseNumberDataGridViewTextBoxColumn.Width = 150;
            // 
            // licenseExpiryDateDataGridViewTextBoxColumn
            // 
            this.licenseExpiryDateDataGridViewTextBoxColumn.DataPropertyName = "LicenseExpiryDate";
            this.licenseExpiryDateDataGridViewTextBoxColumn.HeaderText = "LicenseExpiryDate";
            this.licenseExpiryDateDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.licenseExpiryDateDataGridViewTextBoxColumn.Name = "licenseExpiryDateDataGridViewTextBoxColumn";
            this.licenseExpiryDateDataGridViewTextBoxColumn.Width = 150;
            // 
            // statusDataGridViewTextBoxColumn
            // 
            this.statusDataGridViewTextBoxColumn.DataPropertyName = "Status";
            this.statusDataGridViewTextBoxColumn.HeaderText = "Status";
            this.statusDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.statusDataGridViewTextBoxColumn.Name = "statusDataGridViewTextBoxColumn";
            this.statusDataGridViewTextBoxColumn.Width = 150;
            // 
            // certificationDataGridViewTextBoxColumn
            // 
            this.certificationDataGridViewTextBoxColumn.DataPropertyName = "Certification";
            this.certificationDataGridViewTextBoxColumn.HeaderText = "Certification";
            this.certificationDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.certificationDataGridViewTextBoxColumn.Name = "certificationDataGridViewTextBoxColumn";
            this.certificationDataGridViewTextBoxColumn.Width = 150;
            // 
            // driversBindingSource
            // 
            this.driversBindingSource.DataMember = "Drivers";
            this.driversBindingSource.DataSource = this.cargo_Management_SystemDataSet;
            // 
            // cargo_Management_SystemDataSet
            // 
            this.cargo_Management_SystemDataSet.DataSetName = "Cargo_Management_SystemDataSet";
            this.cargo_Management_SystemDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // VRExitbutton
            // 
            this.VRExitbutton.BackColor = System.Drawing.Color.Teal;
            this.VRExitbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VRExitbutton.ForeColor = System.Drawing.Color.MintCream;
            this.VRExitbutton.Location = new System.Drawing.Point(713, 542);
            this.VRExitbutton.Name = "VRExitbutton";
            this.VRExitbutton.Size = new System.Drawing.Size(111, 41);
            this.VRExitbutton.TabIndex = 39;
            this.VRExitbutton.Text = "Exit";
            this.VRExitbutton.UseVisualStyleBackColor = false;
            this.VRExitbutton.Click += new System.EventHandler(this.VRExitbutton_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Location = new System.Drawing.Point(0, 367);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1005, 10);
            this.panel1.TabIndex = 58;
            // 
            // driversTableAdapter
            // 
            this.driversTableAdapter.ClearBeforeFill = true;
            // 
            // AddDriverbutton
            // 
            this.AddDriverbutton.BackColor = System.Drawing.Color.Teal;
            this.AddDriverbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddDriverbutton.ForeColor = System.Drawing.Color.MintCream;
            this.AddDriverbutton.Location = new System.Drawing.Point(550, 542);
            this.AddDriverbutton.Name = "AddDriverbutton";
            this.AddDriverbutton.Size = new System.Drawing.Size(119, 41);
            this.AddDriverbutton.TabIndex = 39;
            this.AddDriverbutton.Text = "Add";
            this.AddDriverbutton.UseVisualStyleBackColor = false;
            this.AddDriverbutton.Click += new System.EventHandler(this.VUpdatebutton_Click);
            // 
            // DriverLiscencedateTimePicker
            // 
            this.DriverLiscencedateTimePicker.Location = new System.Drawing.Point(513, 468);
            this.DriverLiscencedateTimePicker.Name = "DriverLiscencedateTimePicker";
            this.DriverLiscencedateTimePicker.Size = new System.Drawing.Size(200, 26);
            this.DriverLiscencedateTimePicker.TabIndex = 70;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Teal;
            this.label6.Location = new System.Drawing.Point(276, 471);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(215, 25);
            this.label6.TabIndex = 69;
            this.label6.Text = "Liscense Expiry Date";
            // 
            // DriverFirstNametextBox
            // 
            this.DriverFirstNametextBox.Location = new System.Drawing.Point(261, 405);
            this.DriverFirstNametextBox.Name = "DriverFirstNametextBox";
            this.DriverFirstNametextBox.Size = new System.Drawing.Size(161, 26);
            this.DriverFirstNametextBox.TabIndex = 68;
            // 
            // DriverLastNametextBox
            // 
            this.DriverLastNametextBox.Location = new System.Drawing.Point(674, 402);
            this.DriverLastNametextBox.Name = "DriverLastNametextBox";
            this.DriverLastNametextBox.Size = new System.Drawing.Size(132, 26);
            this.DriverLastNametextBox.TabIndex = 67;
            // 
            // DriverLiscenceNotextBox
            // 
            this.DriverLiscenceNotextBox.Location = new System.Drawing.Point(155, 467);
            this.DriverLiscenceNotextBox.Name = "DriverLiscenceNotextBox";
            this.DriverLiscenceNotextBox.Size = new System.Drawing.Size(100, 26);
            this.DriverLiscenceNotextBox.TabIndex = 66;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Teal;
            this.label5.Location = new System.Drawing.Point(122, 403);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(110, 25);
            this.label5.TabIndex = 65;
            this.label5.Text = "FirstName";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Teal;
            this.label4.Location = new System.Drawing.Point(545, 403);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 25);
            this.label4.TabIndex = 64;
            this.label4.Text = "LastName";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Teal;
            this.label3.Location = new System.Drawing.Point(12, 466);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(120, 25);
            this.label3.TabIndex = 63;
            this.label3.Text = "License No";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Teal;
            this.label2.Location = new System.Drawing.Point(750, 468);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 25);
            this.label2.TabIndex = 62;
            this.label2.Text = "Status";
            // 
            // DriverStatuscomboobx
            // 
            this.DriverStatuscomboobx.FormattingEnabled = true;
            this.DriverStatuscomboobx.Items.AddRange(new object[] {
            "Free",
            "Active",
            "Suspended"});
            this.DriverStatuscomboobx.Location = new System.Drawing.Point(842, 468);
            this.DriverStatuscomboobx.Name = "DriverStatuscomboobx";
            this.DriverStatuscomboobx.Size = new System.Drawing.Size(132, 28);
            this.DriverStatuscomboobx.TabIndex = 59;
            // 
            // DriverCertificationtextBox
            // 
            this.DriverCertificationtextBox.Location = new System.Drawing.Point(155, 526);
            this.DriverCertificationtextBox.Name = "DriverCertificationtextBox";
            this.DriverCertificationtextBox.Size = new System.Drawing.Size(155, 26);
            this.DriverCertificationtextBox.TabIndex = 72;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Teal;
            this.label1.Location = new System.Drawing.Point(12, 525);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(127, 25);
            this.label1.TabIndex = 71;
            this.label1.Text = "Certification";
            // 
            // DriverRegisterationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MintCream;
            this.ClientSize = new System.Drawing.Size(1005, 603);
            this.Controls.Add(this.DriverCertificationtextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.DriverLiscencedateTimePicker);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.DriverFirstNametextBox);
            this.Controls.Add(this.DriverLastNametextBox);
            this.Controls.Add(this.DriverLiscenceNotextBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.DriverStatuscomboobx);
            this.Controls.Add(this.AddDriverbutton);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.VRExitbutton);
            this.Controls.Add(this.MVdataGridView);
            this.Controls.Add(this.warehouseformpanel);
            this.Name = "DriverRegisterationForm";
            this.Text = "DriverRegisterationForm";
            this.Load += new System.EventHandler(this.DriverRegisterationForm_Load);
            this.warehouseformpanel.ResumeLayout(false);
            this.warehouseformpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MVdataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.driversBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cargo_Management_SystemDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel warehouseformpanel;
        private System.Windows.Forms.Label warehouseFormlabel;
        private System.Windows.Forms.Label namelabel;
        private System.Windows.Forms.DataGridView MVdataGridView;
        private System.Windows.Forms.Button VRExitbutton;
        private System.Windows.Forms.Panel panel1;
        private Cargo_Management_SystemDataSet cargo_Management_SystemDataSet;
        private System.Windows.Forms.BindingSource driversBindingSource;
        private Cargo_Management_SystemDataSetTableAdapters.DriversTableAdapter driversTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn driverIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn licenseNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn licenseExpiryDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn statusDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn certificationDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button AddDriverbutton;
        private System.Windows.Forms.DateTimePicker DriverLiscencedateTimePicker;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox DriverFirstNametextBox;
        private System.Windows.Forms.TextBox DriverLastNametextBox;
        private System.Windows.Forms.TextBox DriverLiscenceNotextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox DriverStatuscomboobx;
        private System.Windows.Forms.TextBox DriverCertificationtextBox;
        private System.Windows.Forms.Label label1;
    }
}