﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cargo_Management_system
{
    public partial class ClientForm : Form
    {
        public ClientForm()
        {
            InitializeComponent();
        }

        private void ClientForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'cargo_Management_SystemDataSet.Clients' table. 
            this.clientsTableAdapter.Fill(this.cargo_Management_SystemDataSet.Clients);

        }

        private void Exittbutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Addbutton_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-04KFGU9\\SQLSERVER2022;Initial Catalog=\"Cargo Management System\";Integrated Security=True;Encrypt=False";
            string insertQuery = @"INSERT INTO Clients (CompanyName, ContactName, Address, PhoneNumber, Email)
                                   VALUES (@CompanyName, @ContactName, @Address, @PhoneNumber, @Email)";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(insertQuery, con))
                {
                    
                    cmd.Parameters.AddWithValue("@CompanyName", CompanyNametextBox.Text); 
                    cmd.Parameters.AddWithValue("@ContactName", ContactNametextBox.Text); 
                    cmd.Parameters.AddWithValue("@Address", AddresstextBox.Text); 
                    cmd.Parameters.AddWithValue("@PhoneNumber", PhoneNotextBox.Text); 
                    cmd.Parameters.AddWithValue("@Email", EmailtextBox.Text); 

                    try
                    {
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();

                        // Show a success message
                        MessageBox.Show("Driver data inserted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        // Show an error message
                        MessageBox.Show($"Error inserting data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            this.Close();
        }

        private void Updatebutton_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-04KFGU9\\SQLSERVER2022;Initial Catalog=\"Cargo Management System\";Integrated Security=True;Encrypt=False";
            string updateQuery = @"UPDATE Clients SET CompanyName = @CompanyName,ContactName = @ContactName,Address = @Address, PhoneNumber = @PhoneNumber,
                                 Email = @Email WHERE ClientID = @ClientID";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(updateQuery, con))
                {
                  
                    cmd.Parameters.AddWithValue("@CompanyName", CompanyNametextBox.Text); 
                    cmd.Parameters.AddWithValue("@ContactName", ContactNametextBox.Text); 
                    cmd.Parameters.AddWithValue("@Address", AddresstextBox.Text); 
                    cmd.Parameters.AddWithValue("@PhoneNumber", PhoneNotextBox.Text); 
                    cmd.Parameters.AddWithValue("@Email", EmailtextBox.Text); 
                    cmd.Parameters.AddWithValue("@ClientID", int.Parse(ClientIDcomboBox.Text)); 

                    try
                    {
                        con.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        con.Close();

                        // Show a success message if rowsAffected is greater than 0
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Client record updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("No client record found with the specified ClientID to update.", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    catch (Exception ex)
                    {
                        // Show an error message
                        MessageBox.Show($"Error updating client record: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }

            this.Close();
        }

        private void Deletebutton_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-04KFGU9\\SQLSERVER2022;Initial Catalog=\"Cargo Management System\";Integrated Security=True;Encrypt=False";
            string deleteQuery = @"DELETE FROM Clients WHERE ClientID = @ClientID";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(deleteQuery, con))
                {
                    cmd.Parameters.AddWithValue("@ClientID", int.Parse(ClientIDcomboBox.Text)); 

                    try
                    {
                        con.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        con.Close();

                        // Show a success message if rowsAffected is greater than 0
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Client record deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("No client record found with the specified ClientID.", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    catch (Exception ex)
                    {
                        // Show an error message
                        MessageBox.Show($"Error deleting client record: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            this.Close();
        }

        private void ClientsDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                ClientIDcomboBox.Text = ClientsDataGridView.Rows[e.RowIndex].Cells[0].Value.ToString(); 
                CompanyNametextBox.Text = ClientsDataGridView.Rows[e.RowIndex].Cells[1].Value.ToString(); 
                ContactNametextBox.Text = ClientsDataGridView.Rows[e.RowIndex].Cells[2].Value.ToString(); 
                AddresstextBox.Text = ClientsDataGridView.Rows[e.RowIndex].Cells[3].Value.ToString(); 
                PhoneNotextBox.Text = ClientsDataGridView.Rows[e.RowIndex].Cells[4].Value.ToString(); 
                EmailtextBox.Text = ClientsDataGridView.Rows[e.RowIndex].Cells[5].Value.ToString(); 
            }

        }
    }
}
