﻿namespace Cargo_Management_system
{
    partial class MaintenanceRecordForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.warehouseformpanel = new System.Windows.Forms.Panel();
            this.MaintenanceRecordFormlabel = new System.Windows.Forms.Label();
            this.namelabel = new System.Windows.Forms.Label();
            this.MVdataGridView = new System.Windows.Forms.DataGridView();
            this.recordIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vehicleIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.costDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.maintenanceRecordsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cargo_Management_SystemDataSet = new Cargo_Management_system.Cargo_Management_SystemDataSet();
            this.panel1 = new System.Windows.Forms.Panel();
            this.VeichleIDcomboBox = new System.Windows.Forms.ComboBox();
            this.CosttextBox = new System.Windows.Forms.TextBox();
            this.DescriptiontextBox = new System.Windows.Forms.TextBox();
            this.MaintenancedateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.locnamelabel = new System.Windows.Forms.Label();
            this.ExitMaintananceRecordbutton = new System.Windows.Forms.Button();
            this.AddMaintananceRecordbutton = new System.Windows.Forms.Button();
            this.fuelLogsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.fuelLogsTableAdapter = new Cargo_Management_system.Cargo_Management_SystemDataSetTableAdapters.FuelLogsTableAdapter();
            this.maintenanceRecordsTableAdapter = new Cargo_Management_system.Cargo_Management_SystemDataSetTableAdapters.MaintenanceRecordsTableAdapter();
            this.ManageMaintenanceRecordbutton = new System.Windows.Forms.Button();
            this.vehiclesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.vehiclesTableAdapter = new Cargo_Management_system.Cargo_Management_SystemDataSetTableAdapters.VehiclesTableAdapter();
            this.warehouseformpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MVdataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.maintenanceRecordsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cargo_Management_SystemDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fuelLogsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vehiclesBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // warehouseformpanel
            // 
            this.warehouseformpanel.BackColor = System.Drawing.Color.Teal;
            this.warehouseformpanel.Controls.Add(this.MaintenanceRecordFormlabel);
            this.warehouseformpanel.Controls.Add(this.namelabel);
            this.warehouseformpanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.warehouseformpanel.Location = new System.Drawing.Point(0, 0);
            this.warehouseformpanel.Name = "warehouseformpanel";
            this.warehouseformpanel.Size = new System.Drawing.Size(1005, 101);
            this.warehouseformpanel.TabIndex = 7;
            // 
            // MaintenanceRecordFormlabel
            // 
            this.MaintenanceRecordFormlabel.AutoSize = true;
            this.MaintenanceRecordFormlabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaintenanceRecordFormlabel.ForeColor = System.Drawing.Color.MintCream;
            this.MaintenanceRecordFormlabel.Location = new System.Drawing.Point(297, 33);
            this.MaintenanceRecordFormlabel.Name = "MaintenanceRecordFormlabel";
            this.MaintenanceRecordFormlabel.Size = new System.Drawing.Size(351, 42);
            this.MaintenanceRecordFormlabel.TabIndex = 1;
            this.MaintenanceRecordFormlabel.Text = "Maintenance Record";
            // 
            // namelabel
            // 
            this.namelabel.AutoSize = true;
            this.namelabel.ForeColor = System.Drawing.Color.MintCream;
            this.namelabel.Location = new System.Drawing.Point(291, 33);
            this.namelabel.Name = "namelabel";
            this.namelabel.Size = new System.Drawing.Size(0, 20);
            this.namelabel.TabIndex = 0;
            // 
            // MVdataGridView
            // 
            this.MVdataGridView.AutoGenerateColumns = false;
            this.MVdataGridView.BackgroundColor = System.Drawing.Color.MintCream;
            this.MVdataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.MVdataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.recordIDDataGridViewTextBoxColumn,
            this.vehicleIDDataGridViewTextBoxColumn,
            this.dateDataGridViewTextBoxColumn,
            this.descriptionDataGridViewTextBoxColumn,
            this.costDataGridViewTextBoxColumn});
            this.MVdataGridView.DataSource = this.maintenanceRecordsBindingSource;
            this.MVdataGridView.Dock = System.Windows.Forms.DockStyle.Top;
            this.MVdataGridView.GridColor = System.Drawing.Color.Teal;
            this.MVdataGridView.Location = new System.Drawing.Point(0, 101);
            this.MVdataGridView.Name = "MVdataGridView";
            this.MVdataGridView.RowHeadersWidth = 62;
            this.MVdataGridView.RowTemplate.Height = 28;
            this.MVdataGridView.Size = new System.Drawing.Size(1005, 276);
            this.MVdataGridView.TabIndex = 36;
            // 
            // recordIDDataGridViewTextBoxColumn
            // 
            this.recordIDDataGridViewTextBoxColumn.DataPropertyName = "RecordID";
            this.recordIDDataGridViewTextBoxColumn.HeaderText = "RecordID";
            this.recordIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.recordIDDataGridViewTextBoxColumn.Name = "recordIDDataGridViewTextBoxColumn";
            this.recordIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.recordIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // vehicleIDDataGridViewTextBoxColumn
            // 
            this.vehicleIDDataGridViewTextBoxColumn.DataPropertyName = "VehicleID";
            this.vehicleIDDataGridViewTextBoxColumn.HeaderText = "VehicleID";
            this.vehicleIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.vehicleIDDataGridViewTextBoxColumn.Name = "vehicleIDDataGridViewTextBoxColumn";
            this.vehicleIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // dateDataGridViewTextBoxColumn
            // 
            this.dateDataGridViewTextBoxColumn.DataPropertyName = "Date";
            this.dateDataGridViewTextBoxColumn.HeaderText = "Date";
            this.dateDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.dateDataGridViewTextBoxColumn.Name = "dateDataGridViewTextBoxColumn";
            this.dateDataGridViewTextBoxColumn.Width = 150;
            // 
            // descriptionDataGridViewTextBoxColumn
            // 
            this.descriptionDataGridViewTextBoxColumn.DataPropertyName = "Description";
            this.descriptionDataGridViewTextBoxColumn.HeaderText = "Description";
            this.descriptionDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.descriptionDataGridViewTextBoxColumn.Name = "descriptionDataGridViewTextBoxColumn";
            this.descriptionDataGridViewTextBoxColumn.Width = 150;
            // 
            // costDataGridViewTextBoxColumn
            // 
            this.costDataGridViewTextBoxColumn.DataPropertyName = "Cost";
            this.costDataGridViewTextBoxColumn.HeaderText = "Cost";
            this.costDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.costDataGridViewTextBoxColumn.Name = "costDataGridViewTextBoxColumn";
            this.costDataGridViewTextBoxColumn.Width = 150;
            // 
            // maintenanceRecordsBindingSource
            // 
            this.maintenanceRecordsBindingSource.DataMember = "MaintenanceRecords";
            this.maintenanceRecordsBindingSource.DataSource = this.cargo_Management_SystemDataSet;
            // 
            // cargo_Management_SystemDataSet
            // 
            this.cargo_Management_SystemDataSet.DataSetName = "Cargo_Management_SystemDataSet";
            this.cargo_Management_SystemDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Location = new System.Drawing.Point(0, 367);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1005, 10);
            this.panel1.TabIndex = 48;
            // 
            // VeichleIDcomboBox
            // 
            this.VeichleIDcomboBox.DataSource = this.vehiclesBindingSource;
            this.VeichleIDcomboBox.DisplayMember = "VehiclesID";
            this.VeichleIDcomboBox.FormattingEnabled = true;
            this.VeichleIDcomboBox.Location = new System.Drawing.Point(334, 409);
            this.VeichleIDcomboBox.Name = "VeichleIDcomboBox";
            this.VeichleIDcomboBox.Size = new System.Drawing.Size(121, 28);
            this.VeichleIDcomboBox.TabIndex = 74;
            this.VeichleIDcomboBox.ValueMember = "VehiclesID";
            // 
            // CosttextBox
            // 
            this.CosttextBox.Location = new System.Drawing.Point(334, 478);
            this.CosttextBox.Name = "CosttextBox";
            this.CosttextBox.Size = new System.Drawing.Size(100, 26);
            this.CosttextBox.TabIndex = 73;
            // 
            // DescriptiontextBox
            // 
            this.DescriptiontextBox.Location = new System.Drawing.Point(645, 478);
            this.DescriptiontextBox.Name = "DescriptiontextBox";
            this.DescriptiontextBox.Size = new System.Drawing.Size(226, 26);
            this.DescriptiontextBox.TabIndex = 72;
            // 
            // MaintenancedateTimePicker
            // 
            this.MaintenancedateTimePicker.Location = new System.Drawing.Point(645, 415);
            this.MaintenancedateTimePicker.Name = "MaintenancedateTimePicker";
            this.MaintenancedateTimePicker.Size = new System.Drawing.Size(200, 26);
            this.MaintenancedateTimePicker.TabIndex = 70;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Teal;
            this.label5.Location = new System.Drawing.Point(210, 408);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(105, 25);
            this.label5.TabIndex = 69;
            this.label5.Text = "VehicleID";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Teal;
            this.label4.Location = new System.Drawing.Point(554, 415);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 25);
            this.label4.TabIndex = 68;
            this.label4.Text = "Date";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Teal;
            this.label1.Location = new System.Drawing.Point(248, 481);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 25);
            this.label1.TabIndex = 66;
            this.label1.Text = "Cost";
            // 
            // locnamelabel
            // 
            this.locnamelabel.AutoSize = true;
            this.locnamelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.locnamelabel.ForeColor = System.Drawing.Color.Teal;
            this.locnamelabel.Location = new System.Drawing.Point(491, 481);
            this.locnamelabel.Name = "locnamelabel";
            this.locnamelabel.Size = new System.Drawing.Size(120, 25);
            this.locnamelabel.TabIndex = 65;
            this.locnamelabel.Text = "Description";
            // 
            // ExitMaintananceRecordbutton
            // 
            this.ExitMaintananceRecordbutton.BackColor = System.Drawing.Color.Teal;
            this.ExitMaintananceRecordbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExitMaintananceRecordbutton.ForeColor = System.Drawing.Color.MintCream;
            this.ExitMaintananceRecordbutton.Location = new System.Drawing.Point(772, 550);
            this.ExitMaintananceRecordbutton.Name = "ExitMaintananceRecordbutton";
            this.ExitMaintananceRecordbutton.Size = new System.Drawing.Size(111, 41);
            this.ExitMaintananceRecordbutton.TabIndex = 64;
            this.ExitMaintananceRecordbutton.Text = "Exit";
            this.ExitMaintananceRecordbutton.UseVisualStyleBackColor = false;
            this.ExitMaintananceRecordbutton.Click += new System.EventHandler(this.ExitMaintananceRecordbutton_Click);
            // 
            // AddMaintananceRecordbutton
            // 
            this.AddMaintananceRecordbutton.BackColor = System.Drawing.Color.Teal;
            this.AddMaintananceRecordbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddMaintananceRecordbutton.ForeColor = System.Drawing.Color.MintCream;
            this.AddMaintananceRecordbutton.Location = new System.Drawing.Point(603, 550);
            this.AddMaintananceRecordbutton.Name = "AddMaintananceRecordbutton";
            this.AddMaintananceRecordbutton.Size = new System.Drawing.Size(111, 41);
            this.AddMaintananceRecordbutton.TabIndex = 63;
            this.AddMaintananceRecordbutton.Text = "Add";
            this.AddMaintananceRecordbutton.UseVisualStyleBackColor = false;
            this.AddMaintananceRecordbutton.Click += new System.EventHandler(this.AddMaintananceRecordbutton_Click);
            // 
            // fuelLogsBindingSource
            // 
            this.fuelLogsBindingSource.DataMember = "FuelLogs";
            this.fuelLogsBindingSource.DataSource = this.cargo_Management_SystemDataSet;
            // 
            // fuelLogsTableAdapter
            // 
            this.fuelLogsTableAdapter.ClearBeforeFill = true;
            // 
            // maintenanceRecordsTableAdapter
            // 
            this.maintenanceRecordsTableAdapter.ClearBeforeFill = true;
            // 
            // ManageMaintenanceRecordbutton
            // 
            this.ManageMaintenanceRecordbutton.BackColor = System.Drawing.Color.Teal;
            this.ManageMaintenanceRecordbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ManageMaintenanceRecordbutton.ForeColor = System.Drawing.Color.MintCream;
            this.ManageMaintenanceRecordbutton.Location = new System.Drawing.Point(422, 550);
            this.ManageMaintenanceRecordbutton.Name = "ManageMaintenanceRecordbutton";
            this.ManageMaintenanceRecordbutton.Size = new System.Drawing.Size(128, 41);
            this.ManageMaintenanceRecordbutton.TabIndex = 75;
            this.ManageMaintenanceRecordbutton.Text = "Manage ";
            this.ManageMaintenanceRecordbutton.UseVisualStyleBackColor = false;
            this.ManageMaintenanceRecordbutton.Click += new System.EventHandler(this.ManageMaintenanceRecordbutton_Click);
            // 
            // vehiclesBindingSource
            // 
            this.vehiclesBindingSource.DataMember = "Vehicles";
            this.vehiclesBindingSource.DataSource = this.cargo_Management_SystemDataSet;
            // 
            // vehiclesTableAdapter
            // 
            this.vehiclesTableAdapter.ClearBeforeFill = true;
            // 
            // MaintenanceRecordForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MintCream;
            this.ClientSize = new System.Drawing.Size(1005, 603);
            this.Controls.Add(this.ManageMaintenanceRecordbutton);
            this.Controls.Add(this.VeichleIDcomboBox);
            this.Controls.Add(this.CosttextBox);
            this.Controls.Add(this.DescriptiontextBox);
            this.Controls.Add(this.MaintenancedateTimePicker);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.locnamelabel);
            this.Controls.Add(this.ExitMaintananceRecordbutton);
            this.Controls.Add(this.AddMaintananceRecordbutton);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.MVdataGridView);
            this.Controls.Add(this.warehouseformpanel);
            this.Name = "MaintenanceRecordForm";
            this.Text = "MaintenanceRecordForm";
            this.Load += new System.EventHandler(this.MaintenanceRecordForm_Load);
            this.warehouseformpanel.ResumeLayout(false);
            this.warehouseformpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MVdataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.maintenanceRecordsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cargo_Management_SystemDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fuelLogsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vehiclesBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel warehouseformpanel;
        private System.Windows.Forms.Label MaintenanceRecordFormlabel;
        private System.Windows.Forms.Label namelabel;
        private System.Windows.Forms.DataGridView MVdataGridView;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox VeichleIDcomboBox;
        private System.Windows.Forms.TextBox CosttextBox;
        private System.Windows.Forms.TextBox DescriptiontextBox;
        private System.Windows.Forms.DateTimePicker MaintenancedateTimePicker;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label locnamelabel;
        private System.Windows.Forms.Button ExitMaintananceRecordbutton;
        private System.Windows.Forms.Button AddMaintananceRecordbutton;
        private Cargo_Management_SystemDataSet cargo_Management_SystemDataSet;
        private System.Windows.Forms.BindingSource fuelLogsBindingSource;
        private Cargo_Management_SystemDataSetTableAdapters.FuelLogsTableAdapter fuelLogsTableAdapter;
        private System.Windows.Forms.BindingSource maintenanceRecordsBindingSource;
        private Cargo_Management_SystemDataSetTableAdapters.MaintenanceRecordsTableAdapter maintenanceRecordsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn recordIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn vehicleIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn descriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn costDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button ManageMaintenanceRecordbutton;
        private System.Windows.Forms.BindingSource vehiclesBindingSource;
        private Cargo_Management_SystemDataSetTableAdapters.VehiclesTableAdapter vehiclesTableAdapter;
    }
}