﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cargo_Management_system
{
    public partial class WarehouseForm : Form
    {
        public WarehouseForm()
        {
            InitializeComponent();
        }

        private void WarehouseForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'cargo_Management_SystemDataSet.Warehouse' table. You can move, or remove it, as needed.
            this.warehouseTableAdapter.Fill(this.cargo_Management_SystemDataSet.Warehouse);

        }

        private void ExitWarehousebutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void AddWarehousebutton_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-04KFGU9\\SQLSERVER2022;Initial Catalog=\"Cargo Management System\";Integrated Security=True;Encrypt=False"; 
            string insertQuery = @"
INSERT INTO Warehouse (Name, Location, Capacity)
VALUES (@Name, @Location, @Capacity)";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(insertQuery, con))
                {
                    
                    cmd.Parameters.AddWithValue("@Name", WarehouseNametextBox.Text);
                    cmd.Parameters.AddWithValue("@Location", LocationcomboBox.Text);
                    cmd.Parameters.AddWithValue("@Capacity", decimal.Parse(WarehouseCapacitytextBox.Text));

                    try
                    {
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();

                        // Show a success message
                        MessageBox.Show("Warehouse data inserted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        // Show an error message
                        MessageBox.Show($"Error inserting data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            this.Close();
        }

        
    }
}
