﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cargo_Management_system
{
    public partial class FuelLogsForm : Form
    {
        public FuelLogsForm()
        {
            InitializeComponent();
        }

        private void FuelLogsForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'cargo_Management_SystemDataSet.Vehicles' table. You can move, or remove it, as needed.
            this.vehiclesTableAdapter.Fill(this.cargo_Management_SystemDataSet.Vehicles);
            // TODO: This line of code loads data into the 'cargo_Management_SystemDataSet.FuelLogs' table. You can move, or remove it, as needed.
            this.fuelLogsTableAdapter.Fill(this.cargo_Management_SystemDataSet.FuelLogs);

        }

        private void ExitWarehousebutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void ManageFuelLogbutton_Click(object sender, EventArgs e)
        {
            ManageFuelLogForm Form = new ManageFuelLogForm();
            Form.Show();
        }

        private void AddFuelLogbutton_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-04KFGU9\\SQLSERVER2022;Initial Catalog=\"Cargo Management System\";Integrated Security=True;Encrypt=False"; // Replace with your actual connection string
            string insertQuery = @"INSERT INTO FuelLogs (VehicleID, Date, Quantity, Cost, OdometerReading)
                                   VALUES (@VehicleID, @Date, @Quantity, @Cost, @OdometerReading)";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(insertQuery, con))
                {
                   
                    cmd.Parameters.AddWithValue("@VehicleID", VehicleIDcomboBox.Text);
                    cmd.Parameters.AddWithValue("@Date", DateTime.Parse(FuelLogdateTimePicker.Text));
                    cmd.Parameters.AddWithValue("@Quantity", decimal.Parse(QuantitytextBox.Text));
                    cmd.Parameters.AddWithValue("@Cost", decimal.Parse(CosttextBox.Text));
                    cmd.Parameters.AddWithValue("@OdometerReading", decimal.Parse(OdometerReadingtextBox.Text));

                    try
                    {
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();

                        // Show a success message
                        MessageBox.Show("Fuel log data inserted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        // Show an error message
                        MessageBox.Show($"Error inserting fuel log data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            this.Close();

        }
    }
}
